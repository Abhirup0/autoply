'''
LinkedIn Auto Job Applier - Streamlit UI
'''

import streamlit as st
import os
import sys

# Set page configuration
st.set_page_config(
    page_title="LinkedIn Auto Job Applier",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Add the current directory to the path to ensure imports work correctly
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# Custom CSS for styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #0077B5;
        text-align: center;
        margin-bottom: 1rem;
    }
    .sub-header {
        font-size: 1.5rem;
        color: #0077B5;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }
    .info-box {
        background-color: #f0f7fb;
        border-left: 5px solid #0077B5;
        padding: 1rem;
        margin-bottom: 1rem;
    }
    .success-box {
        background-color: #f0fbf0;
        border-left: 5px solid #00B57A;
        padding: 1rem;
        margin-bottom: 1rem;
    }
    .warning-box {
        background-color: #fff8e6;
        border-left: 5px solid #ffc107;
        padding: 1rem;
        margin-bottom: 1rem;
    }
    .stButton button {
        background-color: #0077B5;
        color: white;
        font-weight: bold;
        border-radius: 5px;
        padding: 0.5rem 1rem;
        border: none;
    }
    .stButton button:hover {
        background-color: #005582;
    }
    footer {
        visibility: hidden;
    }
</style>
""", unsafe_allow_html=True)

# Function to load configuration
def load_config(file_path):
    try:
        with open(file_path, 'r') as f:
            content = f.read()
            # Extract variables from Python file
            config = {}
            exec(content, globals(), config)
            # Remove special variables
            for key in list(config.keys()):
                if key.startswith('__'):
                    del config[key]
            return config
    except Exception as e:
        st.error(f"Error loading configuration from {file_path}: {str(e)}")
        return {}

# Function to save configuration
def save_config(file_path, config):
    try:
        # Create backup of original file
        if os.path.exists(file_path):
            with open(f"{file_path}.bak", 'w') as f:
                with open(file_path, 'r') as original:
                    f.write(original.read())

        # Read the original file to preserve comments and structure
        with open(file_path, 'r') as f:
            lines = f.readlines()

        # Create a new file with updated values
        with open(file_path, 'w') as f:
            for line in lines:
                # Check if line is setting a variable
                if '=' in line and not line.strip().startswith('#') and not line.strip().startswith("'''"):
                    var_name = line.split('=')[0].strip()
                    if var_name in config:
                        value = config[var_name]
                        # Format the value based on its type
                        if isinstance(value, str):
                            formatted_value = f'"{value}"'
                        elif isinstance(value, bool):
                            formatted_value = str(value)
                        elif isinstance(value, list):
                            formatted_value = str(value)
                        else:
                            formatted_value = str(value)

                        # Write the updated line
                        f.write(f"{var_name} = {formatted_value}\n")
                    else:
                        f.write(line)
                else:
                    f.write(line)

        return True
    except Exception as e:
        st.error(f"Error saving configuration to {file_path}: {str(e)}")
        return False

# Function to run the bot
def run_bot():
    try:
        # Import the bot runner directly
        from app import streamlit_bot_runner

        # Get the log file path before running
        log_file_path = streamlit_bot_runner.get_log_file_path()

        # Run the bot in a separate thread to not block the UI
        import threading

        def run_bot_thread():
            streamlit_bot_runner.run_bot_with_logging()

        bot_thread = threading.Thread(target=run_bot_thread)
        bot_thread.daemon = True  # Allow the thread to be terminated when the main program exits
        bot_thread.start()

        # Return the log file path
        return True, log_file_path
    except Exception as e:
        st.error(f"Error starting the bot: {str(e)}")
        return False, None

# Main app layout
def main():
    # Apply custom CSS for modern sidebar
    st.markdown("""
    <style>
    /* Modern Sidebar Styling */
    [data-testid="stSidebar"] {
        background-color: #1e3a8a;
        color: white;
    }

    /* Sidebar title */
    [data-testid="stSidebar"] .css-6qob1r,
    [data-testid="stSidebar"] .css-10oheav,
    [data-testid="stSidebar"] .css-ue6h4q,
    [data-testid="stSidebar"] .css-1aehpj {
        color: white !important;
        font-weight: 600 !important;
        font-size: 1.5rem !important;
    }

    /* Radio buttons in sidebar */
    [data-testid="stSidebar"] [role="radiogroup"] label {
        color: white !important;
        font-weight: 500 !important;
        background-color: rgba(255, 255, 255, 0.05) !important;
        padding: 0.85rem 1.25rem !important;
        border-radius: 8px !important;
        margin-bottom: 0.6rem !important;
        cursor: pointer !important;
        transition: all 0.2s ease-out !important;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05) !important;
        border-left: 3px solid transparent !important;
        letter-spacing: 0.3px !important;
        display: flex !important;
        align-items: center !important;
    }

    /* Style for emoji icons in labels */
    [data-testid="stSidebar"] [role="radiogroup"] label span:first-child {
        margin-right: 10px !important;
        font-size: 18px !important;
    }

    /* Radio button hover */
    [data-testid="stSidebar"] [role="radiogroup"] label:hover {
        background-color: rgba(255, 255, 255, 0.1) !important;
        transform: translateX(3px) !important;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1) !important;
    }

    /* Selected radio button */
    [data-testid="stSidebar"] [role="radiogroup"] [data-baseweb="radio"] [aria-checked="true"] + label {
        background-color: rgba(255, 255, 255, 0.15) !important;
        font-weight: 600 !important;
        border-left: 3px solid #60a5fa !important;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1) !important;
    }

    /* Hide radio button circles */
    [data-testid="stSidebar"] [role="radiogroup"] [data-baseweb="radio"] div[role="radio"] {
        display: none !important;
    }

    /* Footer in sidebar */
    .sidebar-footer {
        text-align: center;
        color: rgba(255, 255, 255, 0.7) !important;
        font-size: 12px;
        padding: 1rem;
        margin-top: auto;
    }
    </style>
    """, unsafe_allow_html=True)

    # Header with logo
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown("<h1 class='main-header'>LinkedIn Auto Job Applier</h1>", unsafe_allow_html=True)
        st.markdown("<p style='text-align: center;'>Automate your job applications with AI-powered assistance</p>", unsafe_allow_html=True)

    # Add some spacing at the top of the sidebar
    st.sidebar.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)

    # Define pages with icons
    pages = [
        "📊 Dashboard",
        "👤 Personal Information",
        "❓ Application Questions",
        "🔍 Search Preferences",
        "🔐 Authentication",
        "⚙️ Settings",
        "🚀 Run Bot"
    ]

    # Create radio buttons for navigation
    selection = st.sidebar.radio("Navigation", pages, label_visibility="collapsed")

    # Extract the page name without the icon
    selection = selection.split(" ", 1)[1]

    # Add spacer before footer to move text down
    st.sidebar.markdown("<div style='height: 250px;'></div>", unsafe_allow_html=True)

    # Add footer to sidebar
    st.sidebar.markdown("""
    <div class="sidebar-footer">
        <div>LinkedIn Auto Job Applier</div>
    </div>
    """, unsafe_allow_html=True)

    # Load configurations
    personals_config = load_config("config/personals.py")
    questions_config = load_config("config/questions.py")
    search_config = load_config("config/search.py")
    secrets_config = load_config("config/secrets.py")
    settings_config = load_config("config/settings.py")

    # Dashboard
    if selection == "Dashboard":
        # Custom CSS for the dashboard
        st.markdown("""
        <style>
            /* Dashboard container */
            .dashboard-container {
                background-color: #f8f9fa;
                border-radius: 10px;
                padding: 20px;
                margin-bottom: 20px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            /* Dashboard header */
            .dashboard-header {
                background: linear-gradient(90deg, #1e3a8a 0%, #3b82f6 100%);
                color: white;
                padding: 20px;
                border-radius: 8px;
                margin-bottom: 20px;
                text-align: center;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            /* Status cards */
            .status-container {
                display: flex;
                flex-wrap: wrap;
                gap: 15px;
                margin-bottom: 20px;
            }

            .status-card {
                flex: 1;
                min-width: 150px;
                background-color: white;
                border-radius: 12px;
                padding: 18px 15px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.08);
                text-align: center;
                transition: all 0.3s ease;
                position: relative;
                overflow: hidden;
            }

            .status-card:hover {
                transform: translateY(-3px);
                box-shadow: 0 6px 12px rgba(0, 0, 0, 0.12);
            }

            .status-card::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 4px;
                background-color: #e5e7eb;
            }

            .status-card.complete::before {
                background: linear-gradient(90deg, #059669, #10b981);
            }

            .status-card.incomplete::before {
                background: linear-gradient(90deg, #dc2626, #ef4444);
            }

            .status-card.complete {
                background: linear-gradient(180deg, rgba(16, 185, 129, 0.05) 0%, rgba(255, 255, 255, 0) 50%);
            }

            .status-card.incomplete {
                background: linear-gradient(180deg, rgba(239, 68, 68, 0.05) 0%, rgba(255, 255, 255, 0) 50%);
            }

            .status-icon {
                font-size: 28px;
                margin-bottom: 12px;
                display: inline-block;
                width: 50px;
                height: 50px;
                line-height: 50px;
                border-radius: 50%;
            }

            .status-card.complete .status-icon {
                color: #059669;
                background-color: rgba(16, 185, 129, 0.1);
            }

            .status-card.incomplete .status-icon {
                color: #dc2626;
                background-color: rgba(239, 68, 68, 0.1);
            }

            .status-title {
                font-size: 15px;
                color: #1f2937;
                font-weight: 600;
                margin: 0;
            }

            /* Feature cards */
            .feature-container {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin-bottom: 20px;
            }

            .feature-card {
                background-color: white;
                border-radius: 8px;
                padding: 20px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
                border-left: 4px solid #3b82f6;
            }

            .feature-icon {
                background-color: #dbeafe;
                color: #3b82f6;
                width: 40px;
                height: 40px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 15px;
                font-size: 20px;
            }

            .feature-title {
                font-size: 16px;
                font-weight: 600;
                color: #1f2937;
                margin: 0 0 10px 0;
            }

            .feature-description {
                font-size: 14px;
                color: #4b5563;
                margin: 0;
            }

            /* Stats section */
            .stats-container {
                background-color: white;
                border-radius: 8px;
                padding: 20px;
                margin-bottom: 20px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            }

            .stats-header {
                font-size: 18px;
                font-weight: 600;
                color: #1f2937;
                margin: 0 0 15px 0;
                padding-bottom: 10px;
                border-bottom: 1px solid #e5e7eb;
            }

            .stats-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
                gap: 15px;
            }

            .stat-item {
                text-align: center;
            }

            .stat-value {
                font-size: 24px;
                font-weight: 700;
                color: #1f2937;
                margin: 0;
            }

            .stat-label {
                font-size: 14px;
                color: #4b5563;
                margin: 5px 0 0 0;
            }

            /* Quick actions */
            .actions-container {
                background-color: white;
                border-radius: 8px;
                padding: 20px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            }

            .actions-header {
                font-size: 18px;
                font-weight: 600;
                color: #1f2937;
                margin: 0 0 15px 0;
                padding-bottom: 10px;
                border-bottom: 1px solid #e5e7eb;
            }

            .action-button {
                display: inline-block;
                background-color: #f0f7fb;
                color: #000000;
                padding: 10px 18px;
                border-radius: 6px;
                text-decoration: none;
                font-size: 14px;
                font-weight: 600;
                margin-right: 12px;
                margin-bottom: 12px;
                transition: all 0.3s ease;
                border: 1px solid #e5e7eb;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
                cursor: pointer;
            }

            .action-button:hover {
                background-color: #dbeafe;
                transform: translateY(-2px);
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                border-color: #bfdbfe;
            }

            .action-button i {
                margin-right: 6px;
                font-size: 16px;
            }
        </style>
        """, unsafe_allow_html=True)

        # Dashboard Header
        st.markdown("""
        <div class="dashboard-header">
            <h1 style="margin: 0; font-size: 28px;">LinkedIn Auto Job Applier</h1>
            <p style="margin: 10px 0 0 0; opacity: 0.9;">Automate your job applications with AI-powered assistance</p>
        </div>
        """, unsafe_allow_html=True)

        # Configuration Status Cards
        st.markdown("""
        <div class="dashboard-container">
            <h2 style="margin: 0 0 20px 0; color: #1f2937; font-size: 22px; font-weight: 600;">Configuration Status</h2>
            <div class="status-container">
                <div class="status-card {0}">
                    <div class="status-icon">{1}</div>
                    <p class="status-title">Personal Info</p>
                    <span style="font-size: 12px; color: {10}; display: block; margin-top: 5px;">{11}</span>
                </div>
                <div class="status-card {2}">
                    <div class="status-icon">{3}</div>
                    <p class="status-title">Application Questions</p>
                    <span style="font-size: 12px; color: {12}; display: block; margin-top: 5px;">{13}</span>
                </div>
                <div class="status-card {4}">
                    <div class="status-icon">{5}</div>
                    <p class="status-title">Search Preferences</p>
                    <span style="font-size: 12px; color: {14}; display: block; margin-top: 5px;">{15}</span>
                </div>
                <div class="status-card {6}">
                    <div class="status-icon">{7}</div>
                    <p class="status-title">Authentication</p>
                    <span style="font-size: 12px; color: {16}; display: block; margin-top: 5px;">{17}</span>
                </div>
                <div class="status-card {8}">
                    <div class="status-icon">{9}</div>
                    <p class="status-title">Settings</p>
                    <span style="font-size: 12px; color: {18}; display: block; margin-top: 5px;">{19}</span>
                </div>
            </div>
        </div>
        """.format(
            "complete" if personals_config else "incomplete",
            "✓" if personals_config else "✗",
            "complete" if questions_config else "incomplete",
            "✓" if questions_config else "✗",
            "complete" if search_config else "incomplete",
            "✓" if search_config else "✗",
            "complete" if secrets_config else "incomplete",
            "✓" if secrets_config else "✗",
            "complete" if settings_config else "incomplete",
            "✓" if settings_config else "✗",
            "#059669" if personals_config else "#dc2626",
            "Configured" if personals_config else "Not Configured",
            "#059669" if questions_config else "#dc2626",
            "Configured" if questions_config else "Not Configured",
            "#059669" if search_config else "#dc2626",
            "Configured" if search_config else "Not Configured",
            "#059669" if secrets_config else "#dc2626",
            "Configured" if secrets_config else "Not Configured",
            "#059669" if settings_config else "#dc2626",
            "Configured" if settings_config else "Not Configured"
        ), unsafe_allow_html=True)

        # Feature Cards
        st.markdown("""
        <div class="dashboard-container">
            <h2 style="margin: 0 0 15px 0; color: #1f2937; font-size: 20px;">Key Features</h2>
            <div class="feature-container">
                <div class="feature-card">
                    <div class="feature-icon">🔍</div>
                    <h3 class="feature-title">Smart Job Search</h3>
                    <p class="feature-description">Automatically search for jobs matching your criteria and preferences.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">📝</div>
                    <h3 class="feature-title">Auto Form Filling</h3>
                    <p class="feature-description">Automatically fill out application forms with your pre-configured answers.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🤖</div>
                    <h3 class="feature-title">AI Integration</h3>
                    <p class="feature-description">Use AI to customize your resume and generate tailored responses.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">⚡</div>
                    <h3 class="feature-title">High Efficiency</h3>
                    <p class="feature-description">Apply to 100+ jobs in less than an hour with automated workflows.</p>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # Statistics Section
        # Check if statistics file exists
        stats_file = "bot_stats.txt"
        if os.path.exists(stats_file):
            try:
                with open(stats_file, 'r') as f:
                    stats_data = f.read().strip().split(',')
                    if len(stats_data) >= 3:
                        applied_count = int(stats_data[0])
                        skipped_count = int(stats_data[1])
                        failed_count = int(stats_data[2])
                    else:
                        applied_count, skipped_count, failed_count = 0, 0, 0
            except:
                applied_count, skipped_count, failed_count = 0, 0, 0
        else:
            # Create empty stats file if it doesn't exist
            with open(stats_file, 'w') as f:
                f.write("0,0,0")
            applied_count, skipped_count, failed_count = 0, 0, 0

        st.markdown("""
        <div class="dashboard-container">
            <h2 style="margin: 0 0 15px 0; color: #1f2937; font-size: 20px;">Application Statistics</h2>
            <div class="stats-container">
                <div class="stats-grid">
                    <div class="stat-item">
                        <p class="stat-value">{0}</p>
                        <p class="stat-label">Jobs Applied</p>
                    </div>
                    <div class="stat-item">
                        <p class="stat-value">{1}</p>
                        <p class="stat-label">Jobs Skipped</p>
                    </div>
                    <div class="stat-item">
                        <p class="stat-value">{2}</p>
                        <p class="stat-label">Failed Applications</p>
                    </div>
                    <div class="stat-item">
                        <p class="stat-value">{3}</p>
                        <p class="stat-label">Success Rate</p>
                    </div>
                </div>
            </div>
        </div>
        """.format(
            applied_count,
            skipped_count,
            failed_count,
            f"{int(applied_count / (applied_count + failed_count) * 100)}%" if (applied_count + failed_count) > 0 else "0%"
        ), unsafe_allow_html=True)

        # Quick Actions
        st.markdown("""
        <div class="dashboard-container">
            <h2 style="margin: 0 0 15px 0; color: #1f2937; font-size: 20px;">Quick Actions</h2>
            <div class="actions-container">
                <a href="javascript:void(0);" class="action-button" onclick="window.parent.document.querySelectorAll('[data-testid=\'stSidebar\'] [role=\'radio\']')[6].click(); return false;">
                    <i>🚀</i> Start Bot
                </a>
                <a href="javascript:void(0);" class="action-button" onclick="window.parent.document.querySelectorAll('[data-testid=\'stSidebar\'] [role=\'radio\']')[1].click(); return false;">
                    <i>👤</i> Edit Profile
                </a>
                <a href="javascript:void(0);" class="action-button" onclick="window.parent.document.querySelectorAll('[data-testid=\'stSidebar\'] [role=\'radio\']')[3].click(); return false;">
                    <i>🔍</i> Job Preferences
                </a>
                <a href="javascript:void(0);" class="action-button" onclick="window.parent.document.querySelectorAll('[data-testid=\'stSidebar\'] [role=\'radio\']')[5].click(); return false;">
                    <i>⚙️</i> Settings
                </a>
                <a href="javascript:void(0);" class="action-button" onclick="window.parent.document.querySelectorAll('[data-testid=\'stSidebar\'] [role=\'radio\']')[2].click(); return false;">
                    <i>❓</i> Application Questions
                </a>
                <a href="javascript:void(0);" class="action-button" onclick="window.parent.document.querySelectorAll('[data-testid=\'stSidebar\'] [role=\'radio\']')[4].click(); return false;">
                    <i>🔐</i> Authentication
                </a>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # Getting Started Guide
        st.markdown("""
        <div class="dashboard-container">
            <h2 style="margin: 0 0 15px 0; color: #1f2937; font-size: 20px;">Getting Started</h2>
            <div class="feature-card" style="border-left-color: #10b981;">
                <ol style="margin: 0; padding-left: 20px;">
                    <li style="margin-bottom: 8px; color: #1f2937;">Configure your <strong>Personal Information</strong> in the sidebar</li>
                    <li style="margin-bottom: 8px; color: #1f2937;">Set up your <strong>Application Questions</strong> for automated responses</li>
                    <li style="margin-bottom: 8px; color: #1f2937;">Define your <strong>Search Preferences</strong> to find relevant jobs</li>
                    <li style="margin-bottom: 8px; color: #1f2937;">Enter your <strong>LinkedIn Credentials</strong> in the Authentication section</li>
                    <li style="margin-bottom: 8px; color: #1f2937;">Adjust <strong>Settings</strong> as needed for optimal performance</li>
                    <li style="color: #1f2937;">Go to <strong>Run Bot</strong> to start the automation process</li>
                </ol>
            </div>
        </div>
        """, unsafe_allow_html=True)

    # Personal Information
    elif selection == "Personal Information":
        # Add custom CSS for the Personal Information page
        st.markdown("""
        <style>
            /* Personal Information Page Styling */
            .personal-info-header {
                background: linear-gradient(90deg, #1e3a8a 0%, #3b82f6 100%);
                color: white;
                padding: 20px;
                border-radius: 8px;
                margin-bottom: 25px;
                text-align: center;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .personal-info-container {
                background-color: #f8f9fa;
                border-radius: 10px;
                padding: 25px;
                margin-bottom: 25px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .section-header {
                color: #1e3a8a;
                font-size: 18px;
                font-weight: 600;
                margin-bottom: 15px;
                padding-bottom: 10px;
                border-bottom: 2px solid #e5e7eb;
                display: flex;
                align-items: center;
            }

            .section-header i {
                margin-right: 10px;
                font-size: 20px;
                color: #3b82f6;
            }

            .field-label {
                font-weight: 600;
                color: #1f2937;
                margin-bottom: 5px;
            }

            .field-help {
                font-size: 12px;
                color: #6b7280;
                margin-top: 2px;
            }

            .stButton button {
                background: linear-gradient(90deg, #1e3a8a 0%, #3b82f6 100%);
                color: white;
                font-weight: 600;
                border-radius: 6px;
                padding: 12px 20px;
                border: none;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                transition: all 0.3s ease;
                width: 100%;
                margin-top: 20px;
                font-size: 16px;
            }

            .stButton button:hover {
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                transform: translateY(-2px);
            }

            /* Full-width submit button container */
            .submit-button-container {
                width: 100%;
                margin-top: 30px;
                margin-bottom: 10px;
            }

            .submit-button-container .stButton {
                width: 100%;
            }

            .submit-button-container .stButton button {
                width: 100%;
                font-size: 16px;
                padding: 12px 20px;
            }

            /* Style for form fields */
            .stTextInput input, .stSelectbox select, .stTextArea textarea {
                border-radius: 6px;
                border: 1px solid #d1d5db;
                padding: 10px;
                transition: all 0.3s ease;
            }

            .stTextInput input:focus, .stSelectbox select:focus, .stTextArea textarea:focus {
                border-color: #3b82f6;
                box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
            }

            /* Optional information styling */
            .optional-info {
                background-color: #f0f7fb;
                border-left: 4px solid #3b82f6;
                padding: 10px 15px;
                margin-bottom: 15px;
                border-radius: 0 6px 6px 0;
                font-size: 14px;
                color: #1f2937;
            }

            /* Success message styling */
            .success-message {
                background-color: #ecfdf5;
                border-left: 4px solid #10b981;
                padding: 15px;
                margin-top: 20px;
                border-radius: 0 6px 6px 0;
                display: flex;
                align-items: center;
            }

            .success-message i {
                color: #10b981;
                font-size: 20px;
                margin-right: 10px;
            }

            /* Error message styling */
            .error-message {
                background-color: #fef2f2;
                border-left: 4px solid #ef4444;
                padding: 15px;
                margin-top: 20px;
                border-radius: 0 6px 6px 0;
                display: flex;
                align-items: center;
            }

            .error-message i {
                color: #ef4444;
                font-size: 20px;
                margin-right: 10px;
            }
        </style>
        """, unsafe_allow_html=True)

        # Header
        st.markdown("""
        <div class="personal-info-header">
            <h1 style="margin: 0; font-size: 28px;">Personal Information</h1>
            <p style="margin: 10px 0 0 0; opacity: 0.9;">Configure your profile details for job applications</p>
        </div>
        """, unsafe_allow_html=True)

        # Load existing configuration if available
        existing_config = load_config("config/personals.py")

        # Form with improved styling
        with st.form("personal_info_form"):
            # Basic Information Section
            st.markdown("""
            <div class="personal-info-container">
                <div class="section-header">
                    <i>👤</i> Basic Information
                </div>
            """, unsafe_allow_html=True)

            col1, col2, col3 = st.columns(3)
            with col1:
                first_name = st.text_input(
                    "First Name",
                    value=existing_config.get("first_name", ""),
                    help="Your legal first name as it appears on your ID"
                )
            with col2:
                middle_name = st.text_input(
                    "Middle Name",
                    value=existing_config.get("middle_name", ""),
                    help="Optional: Your middle name or initial"
                )
            with col3:
                last_name = st.text_input(
                    "Last Name",
                    value=existing_config.get("last_name", ""),
                    help="Your legal last name as it appears on your ID"
                )

            col1, col2 = st.columns(2)
            with col1:
                phone_number = st.text_input(
                    "Phone Number",
                    value=existing_config.get("phone_number", ""),
                    help="Your contact phone number with country code"
                )
            with col2:
                current_city = st.text_input(
                    "Current City",
                    value=existing_config.get("current_city", ""),
                    help="Leave empty to use job location"
                )

            st.markdown("</div>", unsafe_allow_html=True)

            # Address Section
            st.markdown("""
            <div class="personal-info-container">
                <div class="section-header">
                    <i>📍</i> Address Information
                </div>
            """, unsafe_allow_html=True)

            street = st.text_input(
                "Street Address",
                value=existing_config.get("street", ""),
                help="Your complete street address including apartment/unit number"
            )

            col1, col2, col3 = st.columns(3)
            with col1:
                state = st.text_input(
                    "State/Province",
                    value=existing_config.get("state", ""),
                    help="Your state or province"
                )
            with col2:
                zipcode = st.text_input(
                    "Zip/Postal Code",
                    value=existing_config.get("zipcode", ""),
                    help="Your postal or zip code"
                )
            with col3:
                country = st.text_input(
                    "Country",
                    value=existing_config.get("country", ""),
                    help="Your country of residence"
                )

            st.markdown("</div>", unsafe_allow_html=True)

            # Equal Opportunity Information Section
            st.markdown("""
            <div class="personal-info-container">
                <div class="section-header">
                    <i>⚖️</i> Equal Opportunity Information
                </div>
                <div class="optional-info">
                    <strong>Note:</strong> This information is optional and used only when required by employers for equal opportunity reporting.
                </div>
            """, unsafe_allow_html=True)

            col1, col2 = st.columns(2)
            with col1:
                ethnicity = st.selectbox(
                    "Ethnicity",
                    ["Decline", "Hispanic/Latino", "American Indian or Alaska Native", "Asian", "Black or African American", "Native Hawaiian or Other Pacific Islander", "White", "Other", ""],
                    index=0
                )

                gender = st.selectbox(
                    "Gender",
                    ["Decline", "Male", "Female", "Other", ""],
                    index=0
                )
            with col2:
                disability_status = st.selectbox(
                    "Disability Status",
                    ["Decline", "Yes", "No", ""],
                    index=0
                )

                veteran_status = st.selectbox(
                    "Veteran Status",
                    ["Decline", "Yes", "No", ""],
                    index=0
                )

            st.markdown("</div>", unsafe_allow_html=True)

            # Submit Button
            st.markdown("<div class='submit-button-container'>", unsafe_allow_html=True)
            submit_button = st.form_submit_button("💾 Save Personal Information")
            st.markdown("</div>", unsafe_allow_html=True)

            if submit_button:
                # Update configuration
                updated_config = {
                    "first_name": first_name,
                    "middle_name": middle_name,
                    "last_name": last_name,
                    "phone_number": phone_number,
                    "current_city": current_city,
                    "street": street,
                    "state": state,
                    "zipcode": zipcode,
                    "country": country,
                    "ethnicity": ethnicity,
                    "gender": gender,
                    "disability_status": disability_status,
                    "veteran_status": veteran_status
                }

                if save_config("config/personals.py", updated_config):
                    st.markdown("""
                    <div class="success-message">
                        <i>✅</i> Personal information saved successfully! Your profile is now ready for job applications.
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown("""
                    <div class="error-message">
                        <i>❌</i> Failed to save personal information. Please check your inputs and try again.
                    </div>
                    """, unsafe_allow_html=True)

    # Application Questions
    elif selection == "Application Questions":
        # Add custom CSS for the Application Questions page
        st.markdown("""
        <style>
            /* Application Questions Page Styling */
            .questions-header {
                background: linear-gradient(90deg, #1e3a8a 0%, #3b82f6 100%);
                color: white;
                padding: 20px;
                border-radius: 8px;
                margin-bottom: 25px;
                text-align: center;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .questions-container {
                background-color: #f8f9fa;
                border-radius: 10px;
                padding: 25px;
                margin-bottom: 25px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .questions-section-header {
                color: #1e3a8a;
                font-size: 18px;
                font-weight: 600;
                margin-bottom: 15px;
                padding-bottom: 10px;
                border-bottom: 2px solid #e5e7eb;
                display: flex;
                align-items: center;
            }

            .questions-section-header i {
                margin-right: 10px;
                font-size: 20px;
                color: #3b82f6;
            }

            .tip-box {
                background-color: #f0f7fb;
                border-left: 4px solid #3b82f6;
                padding: 10px 15px;
                margin-bottom: 15px;
                border-radius: 0 6px 6px 0;
                font-size: 14px;
                color: #1f2937;
            }

            .checkbox-container {
                background-color: #f8f9fa;
                border: 1px solid #e5e7eb;
                border-radius: 6px;
                padding: 10px 15px;
                margin-bottom: 10px;
                transition: all 0.3s ease;
            }

            .checkbox-container:hover {
                border-color: #3b82f6;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            }

            /* Slider styling */
            .stSlider > div > div > div {
                background-color: #3b82f6 !important;
            }

            .stSlider > div > div > div > div {
                background-color: #1e3a8a !important;
                border-color: #1e3a8a !important;
            }
        </style>
        """, unsafe_allow_html=True)

        # Header
        st.markdown("""
        <div class="questions-header">
            <h1 style="margin: 0; font-size: 28px;">Application Questions</h1>
            <p style="margin: 10px 0 0 0; opacity: 0.9;">Configure your answers for common job application questions</p>
        </div>
        """, unsafe_allow_html=True)

        # Load existing configuration if available
        existing_config = load_config("config/questions.py")

        # Form with improved styling
        with st.form("questions_form"):
            # Resume and Experience Section
            st.markdown("""
            <div class="questions-container">
                <div class="questions-section-header">
                    <i>📝</i> Resume and Experience
                </div>
                <div class="tip-box">
                    <strong>Tip:</strong> Make sure your resume path is correct and up-to-date. The bot will use this resume for applications.
                </div>
            """, unsafe_allow_html=True)

            col1, col2 = st.columns(2)
            with col1:
                default_resume_path = st.text_input(
                    "Default Resume Path",
                    value=existing_config.get("default_resume_path", "all resumes/default/resume.pdf"),
                    help="Path to your default resume file"
                )
            with col2:
                years_of_experience = st.text_input(
                    "Years of Experience",
                    value=existing_config.get("years_of_experience", ""),
                    help="Your total professional experience in years"
                )

            st.markdown("</div>", unsafe_allow_html=True)

            # Visa and Citizenship Section
            st.markdown("""
            <div class="questions-container">
                <div class="questions-section-header">
                    <i>🇵🇸</i> Visa and Citizenship
                </div>
            """, unsafe_allow_html=True)

            col1, col2 = st.columns(2)
            with col1:
                require_visa = st.selectbox(
                    "Require Visa Sponsorship",
                    ["Yes", "No"],
                    index=0 if existing_config.get("require_visa") == "Yes" else 1,
                    help="Indicate if you require visa sponsorship from employers"
                )
            with col2:
                us_citizenship = st.selectbox(
                    "US Citizenship Status",
                    ["U.S. Citizen/Permanent Resident", "Non-citizen allowed to work for any employer", "Non-citizen allowed to work for current employer", "Non-citizen seeking work authorization", "Canadian Citizen/Permanent Resident", "Other", ""],
                    index=["U.S. Citizen/Permanent Resident", "Non-citizen allowed to work for any employer", "Non-citizen allowed to work for current employer", "Non-citizen seeking work authorization", "Canadian Citizen/Permanent Resident", "Other", ""].index(existing_config.get("us_citizenship", "U.S. Citizen/Permanent Resident")),
                    help="Your current citizenship or work authorization status"
                )

            st.markdown("</div>", unsafe_allow_html=True)

            # Online Presence Section
            st.markdown("""
            <div class="questions-container">
                <div class="questions-section-header">
                    <i>🌐</i> Online Presence
                </div>
            """, unsafe_allow_html=True)

            col1, col2 = st.columns(2)
            with col1:
                website = st.text_input(
                    "Portfolio Website",
                    value=existing_config.get("website", ""),
                    help="Your personal website or portfolio URL"
                )
            with col2:
                linkedIn = st.text_input(
                    "LinkedIn Profile URL",
                    value=existing_config.get("linkedIn", ""),
                    help="Your LinkedIn profile URL"
                )

            st.markdown("</div>", unsafe_allow_html=True)

            # Salary and Notice Period Section
            st.markdown("""
            <div class="questions-container">
                <div class="questions-section-header">
                    <i>💰</i> Salary and Notice Period
                </div>
                <div class="tip-box">
                    <strong>Note:</strong> Providing salary information helps the bot answer compensation-related questions during applications.
                </div>
            """, unsafe_allow_html=True)

            col1, col2, col3 = st.columns(3)
            with col1:
                desired_salary = st.number_input(
                    "Desired Salary",
                    min_value=0,
                    value=int(existing_config.get("desired_salary", 0)),
                    help="Your expected annual salary"
                )
            with col2:
                current_ctc = st.number_input(
                    "Current CTC",
                    min_value=0,
                    value=int(existing_config.get("current_ctc", 0)),
                    help="Your current annual compensation"
                )
            with col3:
                notice_period = st.number_input(
                    "Notice Period (days)",
                    min_value=0,
                    value=int(existing_config.get("notice_period", 0)),
                    help="How many days notice you need to give your current employer"
                )

            st.markdown("</div>", unsafe_allow_html=True)

            # LinkedIn Profile Section
            st.markdown("""
            <div class="questions-container">
                <div class="questions-section-header">
                    <i>👤</i> LinkedIn Profile
                </div>
            """, unsafe_allow_html=True)

            linkedin_headline = st.text_input(
                "LinkedIn Headline",
                value=existing_config.get("linkedin_headline", ""),
                help="Your professional headline as shown on LinkedIn"
            )

            linkedin_summary = st.text_area(
                "LinkedIn Summary",
                value=existing_config.get("linkedin_summary", ""),
                height=150,
                help="Your professional summary/about section from LinkedIn"
            )

            st.markdown("</div>", unsafe_allow_html=True)

            # Cover Letter and Employment Section
            st.markdown("""
            <div class="questions-container">
                <div class="questions-section-header">
                    <i>📄</i> Cover Letter and Employment
                </div>
                <div class="tip-box">
                    <strong>Tip:</strong> A well-crafted cover letter template will be customized by the bot for each application.
                </div>
            """, unsafe_allow_html=True)

            cover_letter = st.text_area(
                "Cover Letter Template",
                value=existing_config.get("cover_letter", ""),
                height=150,
                help="Your cover letter template that will be customized for each application"
            )

            col1, col2 = st.columns(2)
            with col1:
                recent_employer = st.text_input(
                    "Recent Employer",
                    value=existing_config.get("recent_employer", ""),
                    help="Your most recent or current employer"
                )
            with col2:
                confidence_level = st.select_slider(
                    "Confidence Level (1-10)",
                    options=[str(i) for i in range(1, 11)],
                    value=existing_config.get("confidence_level", "5"),
                    help="How confident the bot should be when answering questions (higher = more assertive)"
                )

            st.markdown("</div>", unsafe_allow_html=True)

            # Application Settings Section
            st.markdown("""
            <div class="questions-container">
                <div class="questions-section-header">
                    <i>⚙️</i> Application Settings
                </div>
                <div class="tip-box">
                    <strong>Tip:</strong> These settings control how the bot behaves during the application process.
                </div>
            """, unsafe_allow_html=True)

            col1, col2, col3 = st.columns(3)
            with col1:
                pause_before_submit = st.checkbox(
                    "Pause Before Submit",
                    value=existing_config.get("pause_before_submit", True),
                    help="Pause for your review before submitting applications"
                )
            with col2:
                pause_at_failed_question = st.checkbox(
                    "Pause at Failed Question",
                    value=existing_config.get("pause_at_failed_question", True),
                    help="Pause when the bot can't answer a question"
                )
            with col3:
                overwrite_previous_answers = st.checkbox(
                    "Overwrite Previous Answers",
                    value=existing_config.get("overwrite_previous_answers", False),
                    help="Overwrite any pre-filled answers in application forms"
                )

            st.markdown("</div>", unsafe_allow_html=True)

            # Submit Button
            st.markdown("<div class='submit-button-container'>", unsafe_allow_html=True)
            submit_button = st.form_submit_button("💾 Save Application Questions")
            st.markdown("</div>", unsafe_allow_html=True)

            if submit_button:
                # Update configuration
                updated_config = {
                    "default_resume_path": default_resume_path,
                    "years_of_experience": years_of_experience,
                    "require_visa": require_visa,
                    "website": website,
                    "linkedIn": linkedIn,
                    "us_citizenship": us_citizenship,
                    "desired_salary": desired_salary,
                    "current_ctc": current_ctc,
                    "notice_period": notice_period,
                    "linkedin_headline": linkedin_headline,
                    "linkedin_summary": linkedin_summary,
                    "cover_letter": cover_letter,
                    "recent_employer": recent_employer,
                    "confidence_level": confidence_level,
                    "pause_before_submit": pause_before_submit,
                    "pause_at_failed_question": pause_at_failed_question,
                    "overwrite_previous_answers": overwrite_previous_answers
                }

                if save_config("config/questions.py", updated_config):
                    st.markdown("""
                    <div class="success-message">
                        <i>✅</i> Application questions saved successfully! The bot will use these answers when applying to jobs.
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown("""
                    <div class="error-message">
                        <i>❌</i> Failed to save application questions. Please check your inputs and try again.
                    </div>
                    """, unsafe_allow_html=True)

    # Search Preferences
    elif selection == "Search Preferences":
        # Add custom CSS for the Search Preferences page
        st.markdown("""
        <style>
            /* Search Preferences Page Styling */
            .search-header {
                background: linear-gradient(90deg, #1e3a8a 0%, #3b82f6 100%);
                color: white;
                padding: 20px;
                border-radius: 8px;
                margin-bottom: 25px;
                text-align: center;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .search-container {
                background-color: #f8f9fa;
                border-radius: 10px;
                padding: 25px;
                margin-bottom: 25px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .search-section-header {
                color: #1e3a8a;
                font-size: 18px;
                font-weight: 600;
                margin-bottom: 15px;
                padding-bottom: 10px;
                border-bottom: 2px solid #e5e7eb;
                display: flex;
                align-items: center;
            }

            .search-section-header i {
                margin-right: 10px;
                font-size: 20px;
                color: #3b82f6;
            }

            .filter-tag {
                display: inline-block;
                background-color: #dbeafe;
                color: #1e3a8a;
                padding: 5px 10px;
                border-radius: 15px;
                margin-right: 8px;
                margin-bottom: 8px;
                font-size: 14px;
                font-weight: 500;
            }

            .filter-container {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                margin-top: 10px;
            }

            .filter-item {
                background-color: #f8f9fa;
                border: 1px solid #e5e7eb;
                border-radius: 6px;
                padding: 10px;
                flex: 1;
                min-width: 200px;
                transition: all 0.3s ease;
            }

            .filter-item:hover {
                border-color: #3b82f6;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            }

            .tip-box {
                background-color: #f0f7fb;
                border-left: 4px solid #3b82f6;
                padding: 10px 15px;
                margin-bottom: 15px;
                border-radius: 0 6px 6px 0;
                font-size: 14px;
                color: #1f2937;
            }
        </style>
        """, unsafe_allow_html=True)

        # Header
        st.markdown("""
        <div class="search-header">
            <h1 style="margin: 0; font-size: 28px;">Search Preferences</h1>
            <p style="margin: 10px 0 0 0; opacity: 0.9;">Configure your job search criteria and filters</p>
        </div>
        """, unsafe_allow_html=True)

        # Load existing configuration if available
        existing_config = load_config("config/search.py")

        # Form with improved styling
        with st.form("search_form"):
            # Search Terms Section
            st.markdown("""
            <div class="search-container">
                <div class="search-section-header">
                    <i>🔍</i> Search Terms
                </div>
                <div class="tip-box">
                    <strong>Tip:</strong> Enter job titles or keywords separated by commas. The bot will search for these terms on LinkedIn.
                </div>
            """, unsafe_allow_html=True)

            # Get existing search terms as a comma-separated string
            existing_terms = ", ".join([term.strip('"') for term in existing_config.get("search_terms", [])]) if existing_config.get("search_terms") else "Software Engineer, Software Developer"

            search_terms_str = st.text_area(
                "Search Terms (comma-separated)",
                value=existing_terms,
                help="Enter job titles or keywords separated by commas",
                height=100
            )

            col1, col2 = st.columns(2)
            with col1:
                search_location = st.text_input(
                    "Search Location",
                    value=existing_config.get("search_location", ""),
                    help="City, state, or country (leave empty for remote)"
                )
            with col2:
                switch_number = st.number_input(
                    "Switch Search After (applications)",
                    min_value=1,
                    value=existing_config.get("switch_number", 30),
                    help="Number of applications before switching to next search term"
                )

            randomize_search_order = st.checkbox(
                "Randomize Search Order",
                value=existing_config.get("randomize_search_order", False),
                help="Randomize the order of search terms for variety"
            )

            st.markdown("</div>", unsafe_allow_html=True)

            # Job Filters Section
            st.markdown("""
            <div class="search-container">
                <div class="search-section-header">
                    <i>🛍️</i> Job Filters
                </div>
                <div class="tip-box">
                    <strong>Note:</strong> These filters help narrow down job listings to find the most relevant opportunities.
                </div>
            """, unsafe_allow_html=True)

            col1, col2 = st.columns(2)
            with col1:
                sort_by = st.selectbox(
                    "Sort Results By",
                    ["", "Most recent", "Most relevant"],
                    index=0 if not existing_config.get("sort_by") or existing_config.get("sort_by") not in ["Most recent", "Most relevant"] else 1 + ["Most recent", "Most relevant"].index(existing_config.get("sort_by")),
                    help="How LinkedIn should sort the job listings"
                )
            with col2:
                date_posted = st.selectbox(
                    "Date Posted",
                    ["", "Any time", "Past month", "Past week", "Past 24 hours"],
                    index=0 if not existing_config.get("date_posted") or existing_config.get("date_posted") not in ["Any time", "Past month", "Past week", "Past 24 hours"] else 1 + ["Any time", "Past month", "Past week", "Past 24 hours"].index(existing_config.get("date_posted")),
                    help="Filter jobs by how recently they were posted"
                )

            st.markdown("</div>", unsafe_allow_html=True)

            # Additional Filters Section
            st.markdown("""
            <div class="search-container">
                <div class="search-section-header">
                    <i>🔎</i> Additional Filters
                </div>
            """, unsafe_allow_html=True)

            col1, col2 = st.columns(2)
            with col1:
                easy_apply_only = st.checkbox(
                    "Easy Apply Only",
                    value=existing_config.get("easy_apply_only", True),
                    help="Only show jobs that can be applied to with LinkedIn Easy Apply"
                )
                entry_level = st.checkbox(
                    "Entry Level",
                    value=existing_config.get("entry_level", False),
                    help="Include entry-level positions"
                )
            with col2:
                remote_only = st.checkbox(
                    "Remote Only",
                    value=existing_config.get("remote_only", False),
                    help="Only show remote job opportunities"
                )
                mid_senior_level = st.checkbox(
                    "Mid-Senior Level",
                    value=existing_config.get("mid_senior_level", False),
                    help="Include mid to senior level positions"
                )

            st.markdown("</div>", unsafe_allow_html=True)

            # Submit Button
            st.markdown("<div class='submit-button-container'>", unsafe_allow_html=True)
            submit_button = st.form_submit_button("💾 Save Search Preferences")
            st.markdown("</div>", unsafe_allow_html=True)

            if submit_button:
                # Process search terms
                search_terms = [term.strip() for term in search_terms_str.split(",")]
                search_terms = [f'"{term}"' for term in search_terms if term]

                # Update configuration
                updated_config = {
                    "search_terms": search_terms,
                    "search_location": search_location,
                    "switch_number": switch_number,
                    "randomize_search_order": randomize_search_order,
                    "sort_by": sort_by,
                    "date_posted": date_posted,
                    "easy_apply_only": easy_apply_only,
                    "remote_only": remote_only,
                    "entry_level": entry_level,
                    "mid_senior_level": mid_senior_level
                }

                if save_config("config/search.py", updated_config):
                    st.markdown("""
                    <div class="success-message">
                        <i>✅</i> Search preferences saved successfully! The bot will use these criteria when searching for jobs.
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown("""
                    <div class="error-message">
                        <i>❌</i> Failed to save search preferences. Please check your inputs and try again.
                    </div>
                    """, unsafe_allow_html=True)

    # Authentication
    elif selection == "Authentication":
        # Add custom CSS for the Authentication page
        st.markdown("""
        <style>
            /* Authentication Page Styling */
            .auth-header {
                background: linear-gradient(90deg, #1e3a8a 0%, #3b82f6 100%);
                color: white;
                padding: 20px;
                border-radius: 8px;
                margin-bottom: 25px;
                text-align: center;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .auth-container {
                background-color: #f8f9fa;
                border-radius: 10px;
                padding: 25px;
                margin-bottom: 25px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .auth-section-header {
                color: #1e3a8a;
                font-size: 18px;
                font-weight: 600;
                margin-bottom: 15px;
                padding-bottom: 10px;
                border-bottom: 2px solid #e5e7eb;
                display: flex;
                align-items: center;
            }

            .auth-section-header i {
                margin-right: 10px;
                font-size: 20px;
                color: #3b82f6;
            }

            .security-note {
                background-color: #fff8e6;
                border-left: 4px solid #ffc107;
                padding: 10px 15px;
                margin-bottom: 15px;
                border-radius: 0 6px 6px 0;
                font-size: 14px;
                color: #1f2937;
            }

            .ai-note {
                background-color: #f0f7fb;
                border-left: 4px solid #3b82f6;
                padding: 10px 15px;
                margin-bottom: 15px;
                border-radius: 0 6px 6px 0;
                font-size: 14px;
                color: #1f2937;
            }

            .ai-settings-container {
                background-color: #f0f7fb;
                border-radius: 8px;
                padding: 15px;
                margin-top: 15px;
                border: 1px solid #dbeafe;
            }

            .password-field {
                position: relative;
            }

            .password-field input {
                border: 1px solid #d1d5db;
                border-radius: 6px;
                padding: 10px;
                width: 100%;
                transition: all 0.3s ease;
            }

            .password-field input:focus {
                border-color: #3b82f6;
                box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
            }
        </style>
        """, unsafe_allow_html=True)

        # Header
        st.markdown("""
        <div class="auth-header">
            <h1 style="margin: 0; font-size: 28px;">Authentication</h1>
            <p style="margin: 10px 0 0 0; opacity: 0.9;">Configure your LinkedIn credentials and AI settings</p>
        </div>
        """, unsafe_allow_html=True)

        # Load existing configuration if available
        existing_config = load_config("config/secrets.py")

        # Form with improved styling
        with st.form("auth_form"):
            # LinkedIn Credentials Section
            st.markdown("""
            <div class="auth-container">
                <div class="auth-section-header">
                    <i>🔐</i> LinkedIn Credentials
                </div>
                <div class="security-note">
                    <strong>Security Note:</strong> Your credentials are stored locally and are only used to log in to LinkedIn. They are never shared with any third party.
                </div>
            """, unsafe_allow_html=True)

            col1, col2 = st.columns(2)
            with col1:
                username = st.text_input(
                    "LinkedIn Username/Email",
                    value=existing_config.get("username", ""),
                    type="default",
                    help="Your LinkedIn login email or username"
                )
            with col2:
                password = st.text_input(
                    "LinkedIn Password",
                    value=existing_config.get("password", ""),
                    type="password",
                    help="Your LinkedIn password (stored locally only)"
                )

            st.markdown("</div>", unsafe_allow_html=True)

            # AI Settings Section
            st.markdown("""
            <div class="auth-container">
                <div class="auth-section-header">
                    <i>🤖</i> AI Integration
                </div>
                <div class="ai-note">
                    <strong>Note:</strong> AI integration allows the bot to generate customized responses for application questions and cover letters.
                </div>
            """, unsafe_allow_html=True)

            use_AI = st.checkbox(
                "Enable AI Integration",
                value=existing_config.get("use_AI", False),
                help="Use AI to generate responses for application questions"
            )

            # Only show these fields if AI is enabled
            if use_AI:
                st.markdown("""
                <div class="ai-settings-container">
                    <h4 style="margin-top: 0; color: #1e3a8a; font-size: 16px;">AI Configuration</h4>
                """, unsafe_allow_html=True)

                col1, col2 = st.columns(2)
                with col1:
                    llm_api_url = st.text_input(
                        "API URL",
                        value=existing_config.get("llm_api_url", "https://api.openai.com/v1/"),
                        help="API endpoint URL for your AI provider"
                    )
                    llm_api_key = st.text_input(
                        "API Key",
                        value=existing_config.get("llm_api_key", ""),
                        type="password",
                        help="Your API key for authentication (stored locally only)"
                    )
                with col2:
                    llm_model = st.text_input(
                        "Model Name",
                        value=existing_config.get("llm_model", "gpt-4o-mini"),
                        help="The AI model to use (e.g., gpt-4o-mini, gpt-3.5-turbo)"
                    )
                    llm_spec = st.selectbox(
                        "API Specification",
                        ["openai", "openai-like", "openai-like-github", "openai-like-mistral"],
                        index=0 if not existing_config.get("llm_spec") or existing_config.get("llm_spec") not in ["openai", "openai-like", "openai-like-github", "openai-like-mistral"] else ["openai", "openai-like", "openai-like-github", "openai-like-mistral"].index(existing_config.get("llm_spec")),
                        help="The API specification format to use"
                    )

                stream_output = st.checkbox(
                    "Stream AI Output",
                    value=existing_config.get("stream_output", False),
                    help="Show AI responses as they're being generated"
                )

                st.markdown("</div>", unsafe_allow_html=True)

            st.markdown("</div>", unsafe_allow_html=True)

            # Submit Button
            st.markdown("<div class='submit-button-container'>", unsafe_allow_html=True)
            submit_button = st.form_submit_button("💾 Save Authentication Settings")
            st.markdown("</div>", unsafe_allow_html=True)

            if submit_button:
                # Update configuration
                updated_config = {
                    "username": username,
                    "password": password,
                    "use_AI": use_AI
                }

                if use_AI:
                    updated_config.update({
                        "llm_api_url": llm_api_url,
                        "llm_api_key": llm_api_key,
                        "llm_model": llm_model,
                        "llm_spec": llm_spec,
                        "stream_output": stream_output
                    })

                if save_config("config/secrets.py", updated_config):
                    st.markdown("""
                    <div class="success-message">
                        <i>✅</i> Authentication settings saved successfully! The bot will use these credentials to log in to LinkedIn.
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown("""
                    <div class="error-message">
                        <i>❌</i> Failed to save authentication settings. Please check your inputs and try again.
                    </div>
                    """, unsafe_allow_html=True)

    # Settings
    elif selection == "Settings":
        # Add custom CSS for the Settings page
        st.markdown("""
        <style>
            /* Settings Page Styling */
            .settings-header {
                background: linear-gradient(90deg, #1e3a8a 0%, #3b82f6 100%);
                color: white;
                padding: 20px;
                border-radius: 8px;
                margin-bottom: 25px;
                text-align: center;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .settings-container {
                background-color: #f8f9fa;
                border-radius: 10px;
                padding: 25px;
                margin-bottom: 25px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .settings-section-header {
                color: #1e3a8a;
                font-size: 18px;
                font-weight: 600;
                margin-bottom: 15px;
                padding-bottom: 10px;
                border-bottom: 2px solid #e5e7eb;
                display: flex;
                align-items: center;
            }

            .settings-section-header i {
                margin-right: 10px;
                font-size: 20px;
                color: #3b82f6;
            }

            .settings-tip {
                background-color: #f0f7fb;
                border-left: 4px solid #3b82f6;
                padding: 10px 15px;
                margin-bottom: 15px;
                border-radius: 0 6px 6px 0;
                font-size: 14px;
                color: #1f2937;
            }

            .settings-group {
                background-color: #ffffff;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                padding: 15px;
                margin-bottom: 15px;
            }

            .settings-group-title {
                font-size: 16px;
                font-weight: 600;
                color: #1f2937;
                margin-bottom: 10px;
            }
        </style>
        """, unsafe_allow_html=True)

        # Header
        st.markdown("""
        <div class="settings-header">
            <h1 style="margin: 0; font-size: 28px;">Bot Settings</h1>
            <p style="margin: 10px 0 0 0; opacity: 0.9;">Configure general behavior and automation settings</p>
        </div>
        """, unsafe_allow_html=True)

        # Load existing configuration if available
        existing_config = load_config("config/settings.py")

        with st.form("settings_form"):
            # LinkedIn Settings Section
            st.markdown("""
            <div class="settings-container">
                <div class="settings-section-header">
                    <i>🔗</i> LinkedIn Behavior
                </div>
                <div class="settings-tip">
                    <strong>Tip:</strong> These settings control how the bot interacts with LinkedIn during the application process.
                </div>
            """, unsafe_allow_html=True)

            col1, col2 = st.columns(2)
            with col1:
                close_tabs = st.checkbox(
                    "Close External Application Tabs",
                    value=existing_config.get("close_tabs", False),
                    help="Automatically close tabs for external application websites"
                )
                follow_companies = st.checkbox(
                    "Follow Companies After Apply",
                    value=existing_config.get("follow_companies", False),
                    help="Follow companies on LinkedIn after applying to their jobs"
                )
            with col2:
                run_non_stop = st.checkbox(
                    "Run Non-Stop",
                    value=existing_config.get("run_non_stop", False),
                    help="Continue running without pausing between applications"
                )
                alternate_sortby = st.checkbox(
                    "Alternate Sort By",
                    value=existing_config.get("alternate_sortby", True),
                    help="Alternate between different sorting methods for job listings"
                )

            col1, col2 = st.columns(2)
            with col1:
                cycle_date_posted = st.checkbox(
                    "Cycle Date Posted",
                    value=existing_config.get("cycle_date_posted", True),
                    help="Cycle through different date posted filters"
                )
            with col2:
                stop_date_cycle_at_24hr = st.checkbox(
                    "Stop Date Cycle at 24hr",
                    value=existing_config.get("stop_date_cycle_at_24hr", True),
                    help="Stop cycling date filters at 'Past 24 hours'"
                )

            st.markdown("</div>", unsafe_allow_html=True)

            # Additional Settings Section
            st.markdown("""
            <div class="settings-container">
                <div class="settings-section-header">
                    <i>⚙️</i> Advanced Settings
                </div>
                <div class="settings-tip">
                    <strong>Note:</strong> These settings affect the bot's visibility and debugging capabilities.
                </div>
            """, unsafe_allow_html=True)

            col1, col2 = st.columns(2)
            with col1:
                stealth_mode = st.checkbox(
                    "Stealth Mode",
                    value=existing_config.get("stealth_mode", True),
                    help="Use techniques to avoid detection as a bot"
                )
                run_in_background = st.checkbox(
                    "Run in Background",
                    value=existing_config.get("run_in_background", False),
                    help="Run the bot in the background (less visible)"
                )
            with col2:
                headless = st.checkbox(
                    "Headless Mode",
                    value=existing_config.get("headless", False),
                    help="Run Chrome in headless mode (no visible browser)"
                )
                debug_mode = st.checkbox(
                    "Debug Mode",
                    value=existing_config.get("debug_mode", False),
                    help="Enable detailed logging for troubleshooting"
                )

            st.markdown("</div>", unsafe_allow_html=True)

            # Submit Button
            st.markdown("<div class='submit-button-container'>", unsafe_allow_html=True)
            submit_button = st.form_submit_button("💾 Save Settings")
            st.markdown("</div>", unsafe_allow_html=True)

            if submit_button:
                # Update configuration
                updated_config = {
                    "close_tabs": close_tabs,
                    "follow_companies": follow_companies,
                    "run_non_stop": run_non_stop,
                    "alternate_sortby": alternate_sortby,
                    "cycle_date_posted": cycle_date_posted,
                    "stop_date_cycle_at_24hr": stop_date_cycle_at_24hr,
                    "stealth_mode": stealth_mode,
                    "run_in_background": run_in_background,
                    "headless": headless,
                    "debug_mode": debug_mode
                }

                if save_config("config/settings.py", updated_config):
                    st.markdown("""
                    <div class="success-message">
                        <i>✅</i> Settings saved successfully! The bot will use these settings when running.
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown("""
                    <div class="error-message">
                        <i>❌</i> Failed to save settings. Please check your inputs and try again.
                    </div>
                    """, unsafe_allow_html=True)

    # Run Bot
    elif selection == "Run Bot":
        # Add custom CSS for the Run Bot page
        st.markdown("""
        <style>
            /* Run Bot Page Styling */
            .run-header {
                background: linear-gradient(90deg, #1e3a8a 0%, #3b82f6 100%);
                color: white;
                padding: 20px;
                border-radius: 8px;
                margin-bottom: 25px;
                text-align: center;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .run-container {
                background-color: #f8f9fa;
                border-radius: 10px;
                padding: 25px;
                margin-bottom: 25px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .run-section-header {
                color: #1e3a8a;
                font-size: 18px;
                font-weight: 600;
                margin-bottom: 15px;
                padding-bottom: 10px;
                border-bottom: 2px solid #e5e7eb;
                display: flex;
                align-items: center;
            }

            .run-section-header i {
                margin-right: 10px;
                font-size: 20px;
                color: #3b82f6;
            }

            .run-warning {
                background-color: #fff8e6;
                border-left: 4px solid #ffc107;
                padding: 15px;
                margin-bottom: 20px;
                border-radius: 0 6px 6px 0;
                font-size: 14px;
                color: #1f2937;
            }

            .run-warning h3 {
                color: #b45309;
                margin-top: 0;
                margin-bottom: 10px;
                font-size: 16px;
                display: flex;
                align-items: center;
            }

            .run-warning h3 i {
                margin-right: 8px;
            }

            .run-warning ul {
                margin-bottom: 0;
                padding-left: 20px;
            }

            .run-warning li {
                margin-bottom: 5px;
            }

            .run-button {
                background: linear-gradient(90deg, #059669 0%, #10b981 100%);
                color: white;
                font-weight: 600;
                border-radius: 6px;
                padding: 12px 24px;
                border: none;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                transition: all 0.3s ease;
                width: 100%;
                font-size: 16px;
                display: flex;
                align-items: center;
                justify-content: center;
            }

            /* Make Run Bot button full width */
            .submit-button-container button {
                width: 100%;
                font-size: 16px;
                padding: 12px 20px;
            }

            .run-button i {
                margin-right: 8px;
                font-size: 20px;
            }

            .run-button:hover {
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                transform: translateY(-2px);
            }

            .log-container {
                background-color: #1f2937;
                border-radius: 6px;
                padding: 15px;
                margin-top: 20px;
                margin-bottom: 20px;
                color: #f9fafb;
                font-family: 'Consolas', 'Monaco', monospace;
                font-size: 14px;
                overflow: auto;
                max-height: 400px;
            }

            .log-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 10px;
                padding-bottom: 10px;
                border-bottom: 1px solid #374151;
                color: #f9fafb;
            }

            .refresh-button {
                background-color: #374151;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 5px 10px;
                font-size: 12px;
                cursor: pointer;
                transition: background-color 0.2s;
            }

            .refresh-button:hover {
                background-color: #4b5563;
            }

            .status-running {
                background-color: #ecfdf5;
                border-left: 4px solid #10b981;
                padding: 15px;
                margin-bottom: 20px;
                border-radius: 0 6px 6px 0;
                display: flex;
                align-items: center;
                color: #065f46;
                font-weight: 500;
            }

            .status-running i {
                margin-right: 10px;
                font-size: 20px;
                color: #10b981;
            }

            .status-error {
                background-color: #fef2f2;
                border-left: 4px solid #ef4444;
                padding: 15px;
                margin-bottom: 20px;
                border-radius: 0 6px 6px 0;
                display: flex;
                align-items: center;
                color: #b91c1c;
                font-weight: 500;
            }

            .status-error i {
                margin-right: 10px;
                font-size: 20px;
                color: #ef4444;
            }
        </style>
        """, unsafe_allow_html=True)

        # Header
        st.markdown("""
        <div class="run-header">
            <h1 style="margin: 0; font-size: 28px;">Run Bot</h1>
            <p style="margin: 10px 0 0 0; opacity: 0.9;">Start the LinkedIn Auto Job Applier bot</p>
        </div>
        """, unsafe_allow_html=True)

        # Instructions Container
        st.markdown("""
        <div class="run-container">
            <div class="run-section-header">
                <i>💻</i> Bot Instructions
            </div>
            <div class="run-warning">
                <h3><i>⚠️</i> Important Notes</h3>
                <ul>
                    <li><strong>Configuration:</strong> Make sure you have configured all settings correctly before running the bot.</li>
                    <li><strong>Browser Window:</strong> The bot will open a Chrome browser window and start applying for jobs.</li>
                    <li><strong>Authentication:</strong> You may need to manually log in to LinkedIn the first time.</li>
                    <li><strong>Interaction:</strong> Do not interact with the browser while the bot is running unless prompted.</li>
                    <li><strong>Monitoring:</strong> You can monitor the bot's progress in the log display below.</li>
                </ul>
            </div>
        """, unsafe_allow_html=True)

        # Check if all configurations are loaded
        all_configs_loaded = all([personals_config, questions_config, search_config, secrets_config, settings_config])

        if not all_configs_loaded:
            st.markdown("""
            <div class="status-error">
                <i>❌</i> Please configure all settings before running the bot. Check the sidebar navigation to complete all required sections.
            </div>
            """, unsafe_allow_html=True)
        else:
            # Run Button
            st.markdown("<div class='submit-button-container'>", unsafe_allow_html=True)
            run_button = st.button("🚀 Start Job Application Bot", key="run_bot")
            st.markdown("</div>", unsafe_allow_html=True)

            if run_button:
                    # Create a placeholder for the status
                    status_placeholder = st.empty()
                    status_placeholder.markdown("""
                    <div style="background-color: #f0f7fb; border-left: 4px solid #3b82f6; padding: 15px; border-radius: 0 6px 6px 0;">
                        <i>⏳</i> Starting the bot... Please wait.
                    </div>
                    """, unsafe_allow_html=True)

                    # Run the bot
                    success, log_file_path = run_bot()

                    if success:
                        # Update status
                        status_placeholder.markdown("""
                        <div class="status-running">
                            <i>✅</i> Bot is running! Check the browser window for activity.
                        </div>
                        """, unsafe_allow_html=True)

                        # Create log file viewer with auto-refresh
                        if log_file_path and os.path.exists(log_file_path):
                            st.markdown("""
                            <div class="log-header">
                                <h3 style="margin: 0; font-size: 16px;">Bot Log</h3>
                            </div>
                            """, unsafe_allow_html=True)

                            # Create a placeholder for the log content
                            log_placeholder = st.empty()

                            # Function to read and display log content
                            def read_log_file():
                                try:
                                    with open(log_file_path, 'r') as f:
                                        return f.read()
                                except Exception as e:
                                    return f"Error reading log file: {str(e)}"

                            # Initial log content
                            log_content = read_log_file()
                            log_placeholder.code(log_content, language="text")

                            # Add a refresh button
                            if st.button("🔄 Refresh Log"):
                                log_content = read_log_file()
                                log_placeholder.code(log_content, language="text")

                        st.markdown("""
                        <div class="run-container" style="margin-top: 20px;">
                            <div class="run-section-header">
                                <i>💡</i> Bot Status
                            </div>
                            <p><strong>Status:</strong> Running</p>
                            <p><strong>Browser:</strong> Chrome window is open and automated</p>
                            <p><strong>Monitoring:</strong> You can track progress in the log above</p>
                            <p><strong>To Stop:</strong> Close the browser window or press Ctrl+C in the terminal</p>
                            <p><strong>Refresh:</strong> Click the "Refresh Log" button to see the latest activity</p>
                        </div>
                        """, unsafe_allow_html=True)
                    else:
                        status_placeholder.markdown("""
                        <div class="status-error">
                            <i>❌</i> Failed to start the bot. Check the error message above.
                        </div>
                        """, unsafe_allow_html=True)

        st.markdown("</div>", unsafe_allow_html=True)

    # Footer
    st.markdown("""
    <hr>
    <p style="text-align: center; color: #ffffff;">
        LinkedIn Auto Job Applier | Made with ❤️
    </p>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
