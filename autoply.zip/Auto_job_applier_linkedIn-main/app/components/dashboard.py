'''
Dashboard Component

This module provides the Streamlit dashboard component for visualizing application metrics.
'''

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta

from modules.analytics.metrics import get_metrics_manager

def render_dashboard():
    """Render the analytics dashboard."""
    st.markdown("<div class='main-header'>Application Analytics Dashboard</div>", unsafe_allow_html=True)
    
    # Date filter
    st.markdown("<div class='section-header'>Date Range</div>", unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input(
            "Start Date",
            datetime.now() - timedelta(days=30)
        )
    
    with col2:
        end_date = st.date_input(
            "End Date",
            datetime.now()
        )
    
    # Validate date range
    if start_date > end_date:
        st.error("End date must be after start date.")
        return
    
    # Get metrics data
    metrics_manager = get_metrics_manager()
    stats = metrics_manager.get_application_statistics(
        start_date=start_date.strftime('%Y-%m-%d'),
        end_date=end_date.strftime('%Y-%m-%d')
    )
    
    # Display summary cards
    st.markdown("<div class='section-header'>Summary</div>", unsafe_allow_html=True)
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="Total Applications",
            value=stats['total_applications']
        )
    
    with col2:
        st.metric(
            label="Response Rate",
            value=f"{stats['response_rate']:.1f}%"
        )
    
    with col3:
        st.metric(
            label="Interview Rate",
            value=f"{stats['interview_rate']:.1f}%"
        )
    
    with col4:
        st.metric(
            label="Avg. Time per Application",
            value=f"{stats['avg_time_taken']:.1f}s"
        )
    
    # Daily Applications Chart
    st.markdown("<div class='section-header'>Application Volume</div>", unsafe_allow_html=True)
    
    if stats['daily_applications']:
        dates = list(stats['daily_applications'].keys())
        counts = list(stats['daily_applications'].values())
        
        # Convert string dates to datetime
        dates = [pd.to_datetime(date) for date in dates]
        
        # Create DataFrame for Plotly
        df = pd.DataFrame({
            'Date': dates,
            'Applications': counts
        })
        
        # Sort by date
        df = df.sort_values('Date')
        
        # Create line chart
        fig = px.line(
            df, 
            x='Date', 
            y='Applications',
            markers=True,
            title='Daily Application Volume'
        )
        
        # Update layout
        fig.update_layout(
            xaxis_title='Date',
            yaxis_title='Number of Applications',
            hovermode='x unified'
        )
        
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No application data available for the selected date range.")
    
    # Application Status Chart
    st.markdown("<div class='section-header'>Application Status</div>", unsafe_allow_html=True)
    
    if stats['status_counts']:
        # Create pie chart
        fig = go.Figure(data=[go.Pie(
            labels=list(stats['status_counts'].keys()),
            values=list(stats['status_counts'].values()),
            hole=.4,
            marker_colors=px.colors.qualitative.Plotly
        )])
        
        # Update layout
        fig.update_layout(
            title='Application Status Distribution'
        )
        
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No status data available for the selected date range.")
    
    # Remote vs Non-Remote Chart
    st.markdown("<div class='section-header'>Remote vs. On-Site</div>", unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Create bar chart for remote vs non-remote
        remote_data = pd.DataFrame({
            'Type': ['Remote', 'On-Site'],
            'Count': [stats['remote_count'], stats['non_remote_count']]
        })
        
        fig = px.bar(
            remote_data,
            x='Type',
            y='Count',
            color='Type',
            title='Remote vs. On-Site Jobs'
        )
        
        # Update layout
        fig.update_layout(
            xaxis_title='Job Type',
            yaxis_title='Number of Applications'
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Create donut chart for application methods
        if stats['application_methods']:
            fig = go.Figure(data=[go.Pie(
                labels=list(stats['application_methods'].keys()),
                values=list(stats['application_methods'].values()),
                hole=.4,
                marker_colors=px.colors.qualitative.Set2
            )])
            
            # Update layout
            fig.update_layout(
                title='Application Methods'
            )
            
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No application method data available.")
    
    # Application History Table
    st.markdown("<div class='section-header'>Recent Applications</div>", unsafe_allow_html=True)
    
    applications = metrics_manager.get_application_history()
    
    if applications:
        # Filter by date range
        filtered_apps = []
        for app in applications:
            app_date = pd.to_datetime(app['timestamp']).date()
            if start_date <= app_date <= end_date:
                filtered_apps.append(app)
        
        if filtered_apps:
            # Create DataFrame
            df = pd.DataFrame(filtered_apps)
            
            # Select columns to display
            display_columns = [
                'timestamp', 'job_title', 'company', 'location', 
                'application_status', 'is_remote', 'application_method'
            ]
            
            # Rename columns for display
            column_names = {
                'timestamp': 'Date/Time',
                'job_title': 'Job Title',
                'company': 'Company',
                'location': 'Location',
                'application_status': 'Status',
                'is_remote': 'Remote',
                'application_method': 'Method'
            }
            
            # Format DataFrame for display
            display_df = df[display_columns].rename(columns=column_names)
            
            # Convert boolean to Yes/No
            display_df['Remote'] = display_df['Remote'].map({1: 'Yes', '1': 'Yes', 0: 'No', '0': 'No'})
            
            # Format timestamp
            display_df['Date/Time'] = pd.to_datetime(display_df['Date/Time']).dt.strftime('%Y-%m-%d %H:%M')
            
            # Display table
            st.dataframe(display_df, use_container_width=True)
            
            # Export options
            col1, col2 = st.columns(2)
            
            with col1:
                csv = display_df.to_csv(index=False).encode('utf-8')
                st.download_button(
                    label="Download as CSV",
                    data=csv,
                    file_name=f"linkedin_applications_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv"
                )
            
            with col2:
                excel_file = f"linkedin_applications_{datetime.now().strftime('%Y%m%d')}.xlsx"
                
                @st.cache_data
                def get_excel_data():
                    return display_df.to_excel(index=False, engine='openpyxl')
                
                # This is a placeholder - in a real app you would use st.download_button with Excel bytes
                st.button("Download as Excel", use_container_width=True)
            
        else:
            st.info("No applications found in the selected date range.")
    else:
        st.info("No application history available.")
    
    # Insights
    st.markdown("<div class='section-header'>Insights</div>", unsafe_allow_html=True)
    
    if stats['total_applications'] > 0:
        insights = []
        
        # Add insights based on data
        if stats['response_rate'] > 20:
            insights.append("Your response rate is above average! Keep using the same approach.")
        elif stats['response_rate'] < 10:
            insights.append("Your response rate is lower than average. Consider customizing your resume and cover letter more.")
        
        if stats['interview_rate'] > 10:
            insights.append("Great job! Your interview rate is strong compared to industry averages.")
        
        # Add insights about application volume
        if len(stats['daily_applications']) > 0:
            avg_apps_per_day = stats['total_applications'] / len(stats['daily_applications'])
            if avg_apps_per_day < 3:
                insights.append(f"Your application volume (avg. {avg_apps_per_day:.1f}/day) is relatively low. Consider increasing your activity.")
            elif avg_apps_per_day > 10:
                insights.append(f"You're submitting many applications (avg. {avg_apps_per_day:.1f}/day). Consider focusing on quality over quantity.")
        
        # Remote work insights
        if stats['remote_count'] > 0 and stats['non_remote_count'] > 0:
            remote_percent = (stats['remote_count'] / stats['total_applications']) * 100
            if remote_percent > 75:
                insights.append(f"You're primarily applying to remote positions ({remote_percent:.1f}%). This aligns with current work trends.")
        
        # Display insights
        if insights:
            for insight in insights:
                st.info(insight)
        else:
            st.info("Apply to more jobs to generate personalized insights.")
    else:
        st.info("No data available for insights. Start applying to jobs to see analytics.")

if __name__ == "__main__":
    # For testing the component independently
    st.set_page_config(
        page_title="LinkedIn Auto Job Applier - Dashboard",
        page_icon="📊",
        layout="wide"
    )
    render_dashboard() 