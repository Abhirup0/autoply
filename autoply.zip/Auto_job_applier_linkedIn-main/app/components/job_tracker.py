'''
Job Tracker Component

This module provides the Streamlit component for tracking job applications.
'''

import streamlit as st
import pandas as pd
from datetime import datetime

from modules.analytics.metrics import get_metrics_manager

def render_job_tracker():
    """Render the job application tracker."""
    st.markdown("<div class='main-header'>Job Application Tracker</div>", unsafe_allow_html=True)
    
    # Get metrics manager
    metrics_manager = get_metrics_manager()
    
    # Get application history
    applications = metrics_manager.get_application_history()
    
    # Application status filter
    status_options = ["All"]
    if applications:
        # Get unique statuses
        statuses = set()
        for app in applications:
            status = app.get('application_status')
            if status:
                statuses.add(status)
        
        status_options.extend(sorted(list(statuses)))
    
    selected_status = st.selectbox("Filter by Status", status_options)
    
    # Search box
    search_term = st.text_input("Search", placeholder="Search by job title, company, or location...")
    
    if applications:
        # Filter by status if selected
        if selected_status != "All":
            filtered_apps = [app for app in applications if app.get('application_status') == selected_status]
        else:
            filtered_apps = applications
        
        # Filter by search term if provided
        if search_term:
            search_term = search_term.lower()
            filtered_apps = [
                app for app in filtered_apps 
                if (search_term in app.get('job_title', '').lower() 
                    or search_term in app.get('company', '').lower()
                    or search_term in app.get('location', '').lower())
            ]
        
        if filtered_apps:
            # Create DataFrame
            df = pd.DataFrame(filtered_apps)
            
            # Select columns to display
            display_columns = [
                'timestamp', 'job_title', 'company', 'location', 
                'application_status', 'is_remote', 'job_id'
            ]
            
            # Rename columns for display
            column_names = {
                'timestamp': 'Date/Time',
                'job_title': 'Job Title',
                'company': 'Company',
                'location': 'Location',
                'application_status': 'Status',
                'is_remote': 'Remote',
                'job_id': 'ID'
            }
            
            # Ensure all columns exist
            for col in display_columns:
                if col not in df.columns:
                    df[col] = ""
            
            # Format DataFrame for display
            display_df = df[display_columns].rename(columns=column_names)
            
            # Convert boolean to Yes/No
            display_df['Remote'] = display_df['Remote'].map({1: 'Yes', '1': 'Yes', 0: 'No', '0': 'No', '': 'No'})
            
            # Format timestamp
            display_df['Date/Time'] = pd.to_datetime(display_df['Date/Time']).dt.strftime('%Y-%m-%d %H:%M')
            
            # Display table with selection
            selection = st.dataframe(
                display_df,
                use_container_width=True,
                column_config={
                    "ID": st.column_config.TextColumn(
                        "ID",
                        help="LinkedIn Job ID",
                        visibility="hidden"
                    )
                }
            )
            
            # Handle selected application
            if st.session_state.get('selected_job_id'):
                selected_job_id = st.session_state.get('selected_job_id')
                selected_app = next((app for app in filtered_apps if app.get('job_id') == selected_job_id), None)
                
                if selected_app:
                    _render_application_details(selected_app, metrics_manager)
            elif len(filtered_apps) > 0:
                st.info("Select an application to view details.")
            
            # Export options
            col1, col2 = st.columns(2)
            
            with col1:
                csv = display_df.to_csv(index=False).encode('utf-8')
                st.download_button(
                    label="Export Applications as CSV",
                    data=csv,
                    file_name=f"linkedin_applications_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv"
                )
        else:
            st.info("No applications found matching your filters.")
    else:
        st.info("No application history available. Start applying to jobs to track your progress.")

def _render_application_details(application, metrics_manager):
    """
    Render detailed view for a selected application.
    
    Args:
        application: Application data dictionary
        metrics_manager: Metrics manager instance
    """
    st.markdown("<div class='section-header'>Application Details</div>", unsafe_allow_html=True)
    
    # Basic information
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown(f"**Job Title:** {application.get('job_title', 'N/A')}")
        st.markdown(f"**Company:** {application.get('company', 'N/A')}")
        st.markdown(f"**Location:** {application.get('location', 'N/A')}")
        st.markdown(f"**Remote:** {'Yes' if application.get('is_remote') in [1, '1', True] else 'No'}")
    
    with col2:
        st.markdown(f"**Applied On:** {pd.to_datetime(application.get('timestamp')).strftime('%Y-%m-%d %H:%M')}")
        st.markdown(f"**Application Method:** {application.get('application_method', 'N/A')}")
        st.markdown(f"**Time Taken:** {application.get('time_taken', 'N/A')} seconds")
        
        # Status with colored badge
        status = application.get('application_status', 'N/A')
        status_colors = {
            'applied': '#4CAF50',  # Green
            'viewed': '#2196F3',   # Blue
            'rejected': '#F44336', # Red
            'interview': '#9C27B0', # Purple
            'offer': '#FF9800'     # Orange
        }
        
        status_color = status_colors.get(status.lower(), '#607D8B')  # Default to gray
        
        st.markdown(
            f"**Status:** <span style='background-color: {status_color}; color: white; padding: 3px 8px; border-radius: 3px;'>{status}</span>",
            unsafe_allow_html=True
        )
    
    # Status update section
    st.markdown("<div class='section-header'>Update Status</div>", unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    
    job_id = application.get('job_id')
    
    with col1:
        if st.button("Mark as Viewed", use_container_width=True):
            metrics_manager.update_application_status(job_id, "viewed", response_received=True)
            st.success("Status updated!")
            st.experimental_rerun()
    
    with col2:
        if st.button("Mark as Interview", use_container_width=True):
            metrics_manager.update_application_status(job_id, "interview", response_received=True, interview_offered=True)
            st.success("Status updated!")
            st.experimental_rerun()
    
    with col3:
        if st.button("Mark as Rejected", use_container_width=True):
            metrics_manager.update_application_status(job_id, "rejected", response_received=True)
            st.success("Status updated!")
            st.experimental_rerun()
    
    # Notes section
    st.markdown("<div class='section-header'>Notes</div>", unsafe_allow_html=True)
    
    # This would be connected to a real notes system in a full implementation
    notes = st.text_area("Add notes about this application", height=100)
    
    if st.button("Save Notes"):
        st.success("Notes saved!")
    
    # Details section
    if 'details' in application:
        st.markdown("<div class='section-header'>Job Details</div>", unsafe_allow_html=True)
        
        details = application['details']
        
        # Format and display job details
        if isinstance(details, dict):
            with st.expander("View Job Details", expanded=False):
                for key, value in details.items():
                    if isinstance(value, list):
                        st.markdown(f"**{key.replace('_', ' ').title()}:**")
                        for item in value:
                            st.markdown(f"- {item}")
                    else:
                        st.markdown(f"**{key.replace('_', ' ').title()}:** {value}")
        else:
            st.text(str(details))
    
    # Timeline section (placeholder for a real implementation)
    st.markdown("<div class='section-header'>Application Timeline</div>", unsafe_allow_html=True)
    
    timeline_data = [
        {"date": pd.to_datetime(application.get('timestamp')), "event": "Applied", "details": "Initial application submitted"}
    ]
    
    # Add more events based on status updates (would be implemented in a real system)
    status = application.get('application_status', '').lower()
    
    if status == 'viewed':
        timeline_data.append({
            "date": pd.to_datetime(application.get('timestamp')) + pd.Timedelta(days=2),
            "event": "Viewed",
            "details": "Application viewed by employer"
        })
    elif status == 'interview':
        timeline_data.append({
            "date": pd.to_datetime(application.get('timestamp')) + pd.Timedelta(days=2),
            "event": "Viewed", 
            "details": "Application viewed by employer"
        })
        timeline_data.append({
            "date": pd.to_datetime(application.get('timestamp')) + pd.Timedelta(days=5),
            "event": "Interview Request",
            "details": "Employer requested an interview"
        })
    elif status == 'rejected':
        timeline_data.append({
            "date": pd.to_datetime(application.get('timestamp')) + pd.Timedelta(days=7),
            "event": "Rejected",
            "details": "Application was rejected"
        })
    
    # Create timeline DataFrame
    timeline_df = pd.DataFrame(timeline_data)
    timeline_df['date'] = timeline_df['date'].dt.strftime('%Y-%m-%d')
    
    # Display timeline
    st.dataframe(
        timeline_df,
        use_container_width=True,
        hide_index=True
    )

if __name__ == "__main__":
    # For testing the component independently
    st.set_page_config(
        page_title="LinkedIn Auto Job Applier - Job Tracker",
        page_icon="📋",
        layout="wide"
    )
    render_job_tracker() 