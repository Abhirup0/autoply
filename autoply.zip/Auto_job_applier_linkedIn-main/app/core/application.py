'''
Application Process Module

This module handles the job application process for the LinkedIn Auto Job Applier.
'''

import os
import time
import random
from datetime import datetime
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.remote.webelement import WebElement
from selenium.common.exceptions import (
    TimeoutException, 
    NoSuchElementException, 
    ElementClickInterceptedException,
    ElementNotInteractableException
)

from config.personals import *
from config.questions import *
from config.settings import *
from config.settings import random_radio_answers, random_checkbox_answers
from app.core.browser import get_driver
from app.utils.logging import setup_logging, log_info, log_error, log_warning

logger = setup_logging(__name__)

# Default timeout in seconds
DEFAULT_TIMEOUT = 10

# Dictionary of custom question answers
class SafeDict(dict):
    """Dictionary that returns empty string for missing keys instead of raising KeyError."""
    def __missing__(self, key):
        return ""

custom_questions = SafeDict({
    "how did you hear about us": "LinkedIn",
    "referral": "",
    "cover letter": cover_letter if 'cover_letter' in globals() else "",
    "linkedin profile": linkedIn if 'linkedIn' in globals() else "",
    "portfolio": website if 'website' in globals() else ""
})

class ApplicationManager:
    def __init__(self, driver=None):
        """
        Initialize application manager.
        
        Args:
            driver: Selenium WebDriver instance (default: None, will use global driver)
        """
        self.driver = driver if driver else get_driver()
        self.randomly_answered_questions = set()
        
        # Set default values for form fields if not provided in config
        self._initialize_default_values()
        
    def _initialize_default_values(self):
        """Initialize default values for form fields if not defined in config files."""
        # Default values for personal info
        self.email = globals().get('email', '')
        self.phone = globals().get('phone_number', '')
        self.current_city = globals().get('current_city', '')
        self.current_state = globals().get('state', '')
        self.current_zip = globals().get('zipcode', '')
        self.current_country = globals().get('country', '')
        
        # Default values for education
        self.university = globals().get('university', '')
        self.degree = globals().get('degree', '')
        self.field_of_study = globals().get('field_of_study', '')
        
        # Default values for work experience
        self.years_of_experience = globals().get('years_of_experience', '0')
        self.current_company_name = globals().get('recent_employer', '')
        self.current_title = globals().get('linkedin_headline', '').split(' @ ')[0] if globals().get('linkedin_headline', '') else ''
        
        # Default values for salary
        self.desired_salary = globals().get('desired_salary', '0')
        
        # Default path for resume
        self.default_resume_path = globals().get('default_resume_path', '')
        
        # Application settings
        self.pause_before_submit = globals().get('pause_before_submit', True)
        
        # Work authorization and relocation
        self.willing_to_relocate = globals().get('willing_to_relocate', False)
        self.legally_authorized_to_work = globals().get('legally_authorized_to_work', True)
        self.require_sponsorship = globals().get('require_sponsorship', False)
        
    def handle_application_form(self):
        """
        Handle the job application form.
        
        Returns:
            bool: True if application submitted successfully, False otherwise
        """
        try:
            log_info("Handling application form")
            
            # Get application modal
            modal = WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.presence_of_element_located((By.XPATH, "//div[contains(@class, 'jobs-easy-apply-content')]"))
            )
            
            # Process application steps until complete
            while True:
                # Check if we're done
                if self._is_application_submitted():
                    log_info("Application submitted successfully")
                    return True
                
                # Check if we have a work location
                work_location = self._get_work_location()
                
                # Handle questions on the current page
                questions_list = set()
                questions_list = self._answer_questions(modal, questions_list, work_location)
                
                # Check if we need to upload resume
                self._handle_resume_upload()
                
                # Click Next/Submit button
                if not self._click_next_or_submit():
                    log_warning("Could not find Next/Submit button")
                    break
                
                # Wait for next page to load
                time.sleep(2)
                
            return False
            
        except Exception as e:
            log_error(f"Error handling application form: {e}")
            return False
            
    def _is_application_submitted(self):
        """Check if application has been submitted."""
        try:
            success_elements = self.driver.find_elements(
                By.XPATH, 
                "//div[contains(@class, 'artdeco-inline-feedback--success')]"
            )
            if success_elements:
                return True
                
            done_elements = self.driver.find_elements(
                By.XPATH, 
                "//h2[contains(text(), 'Application submitted') or contains(text(), 'Done')]"
            )
            if done_elements:
                return True
                
            return False
            
        except Exception as e:
            log_error(f"Error checking if application is submitted: {e}")
            return False
            
    def _get_work_location(self):
        """Get job work location from the page."""
        try:
            location_elements = self.driver.find_elements(
                By.XPATH, 
                "//span[contains(@class, 'jobs-unified-top-card__subtitle-primary-grouping')]/span[2]"
            )
            if location_elements:
                return location_elements[0].text.strip()
            return ""
            
        except Exception as e:
            log_error(f"Error getting work location: {e}")
            return ""
            
    def _answer_questions(self, modal, questions_list, work_location):
        """
        Answer job application questions.
        
        Args:
            modal: Application modal WebElement
            questions_list: Set of previously answered questions
            work_location: Job location string
            
        Returns:
            set: Updated set of answered questions
        """
        try:
            # Get all questions
            all_questions = modal.find_elements(By.XPATH, ".//div[@data-test-form-element]")
            
            for question_element in all_questions:
                # Get the question label
                label_elements = question_element.find_elements(By.XPATH, ".//label")
                if not label_elements:
                    continue
                    
                label = label_elements[0].text.strip()
                
                # Skip if already answered
                if label in questions_list:
                    continue
                    
                questions_list.add(label)
                
                log_info(f"Processing question: {label}")
                
                # Handle different question types
                if self._is_input_field(question_element):
                    self._answer_input_question(question_element, label)
                elif self._is_select_field(question_element):
                    self._answer_select_question(question_element, label)
                elif self._is_radio_field(question_element):
                    self._answer_radio_question(question_element, label)
                elif self._is_checkbox_field(question_element):
                    self._answer_checkbox_question(question_element, label)
                else:
                    log_warning(f"Unknown question type for: {label}")
                
            return questions_list
            
        except Exception as e:
            log_error(f"Error answering questions: {e}")
            return questions_list
            
    def _is_input_field(self, element):
        """Check if element contains an input field."""
        return len(element.find_elements(By.XPATH, ".//input[not(@type='radio' or @type='checkbox')]")) > 0
        
    def _is_select_field(self, element):
        """Check if element contains a select field."""
        return len(element.find_elements(By.XPATH, ".//select")) > 0
        
    def _is_radio_field(self, element):
        """Check if element contains radio buttons."""
        return len(element.find_elements(By.XPATH, ".//input[@type='radio']")) > 0
        
    def _is_checkbox_field(self, element):
        """Check if element contains checkboxes."""
        return len(element.find_elements(By.XPATH, ".//input[@type='checkbox']")) > 0
        
    def _answer_input_question(self, element, label):
        """Answer a question with an input field."""
        try:
            input_field = element.find_element(By.XPATH, ".//input")
            
            # Get answer based on question label
            answer = self._get_answer_for_question(label)
            
            if answer:
                input_field.clear()
                input_field.send_keys(answer)
                log_info(f"Answered input question: {label} with {answer}")
            else:
                log_warning(f"No answer found for input question: {label}")
                
        except Exception as e:
            log_error(f"Error answering input question '{label}': {e}")
            
    def _answer_select_question(self, element, label):
        """Answer a question with a select dropdown."""
        try:
            select_field = element.find_element(By.XPATH, ".//select")
            select = Select(select_field)
            
            # Get answer based on question label
            answer = self._get_answer_for_question(label)
            
            if answer:
                # Try to select by visible text
                try:
                    select.select_by_visible_text(answer)
                    log_info(f"Answered select question: {label} with {answer}")
                    return
                except:
                    pass
                    
                # Try to select by value
                try:
                    select.select_by_value(answer)
                    log_info(f"Answered select question: {label} with {answer}")
                    return
                except:
                    pass
                
                # If specific answer not found, select the first non-empty option
                options = select.options
                for option in options:
                    if option.text.strip() and option.text.strip().lower() != "select an option":
                        select.select_by_visible_text(option.text)
                        log_info(f"Selected first available option for {label}: {option.text}")
                        return
                        
                log_warning(f"No suitable option found for select question: {label}")
            else:
                log_warning(f"No answer found for select question: {label}")
                
        except Exception as e:
            log_error(f"Error answering select question '{label}': {e}")
            
    def _answer_radio_question(self, element, label):
        """Answer a question with radio buttons."""
        try:
            radio_buttons = element.find_elements(By.XPATH, ".//input[@type='radio']")
            
            # Get answer based on question label
            answer = self._get_answer_for_question(label)
            
            if answer and answer.lower() in ["yes", "no"]:
                # Find the Yes/No option
                for radio in radio_buttons:
                    # Get the associated label text
                    label_id = radio.get_attribute("id")
                    radio_label = element.find_element(
                        By.XPATH, f".//label[@for='{label_id}']"
                    ).text.strip().lower()
                    
                    if answer.lower() in radio_label:
                        radio.click()
                        log_info(f"Selected {radio_label} for {label}")
                        return
            
            # If no specific answer or not a Yes/No question,
            # select the first or random option based on configuration
            if random_radio_answers:
                random_radio = random.choice(radio_buttons)
                random_radio.click()
                
                # Get the selected option label
                label_id = random_radio.get_attribute("id")
                selected_label = element.find_element(
                    By.XPATH, f".//label[@for='{label_id}']"
                ).text.strip()
                
                log_info(f"Randomly selected {selected_label} for {label}")
                self.randomly_answered_questions.add(f"{label} -> {selected_label}")
            else:
                # Select the first option
                radio_buttons[0].click()
                
                # Get the selected option label
                label_id = radio_buttons[0].get_attribute("id")
                selected_label = element.find_element(
                    By.XPATH, f".//label[@for='{label_id}']"
                ).text.strip()
                
                log_info(f"Selected first option {selected_label} for {label}")
                
        except Exception as e:
            log_error(f"Error answering radio question '{label}': {e}")
            
    def _answer_checkbox_question(self, element, label):
        """Answer a question with checkboxes."""
        try:
            checkboxes = element.find_elements(By.XPATH, ".//input[@type='checkbox']")
            
            # Get answer based on question label
            answer = self._get_answer_for_question(label)
            
            # For legal authorizations, always check 'Yes'
            if "legally authorized" in label.lower() or "work authorization" in label.lower():
                for checkbox in checkboxes:
                    label_id = checkbox.get_attribute("id")
                    checkbox_label = element.find_element(
                        By.XPATH, f".//label[@for='{label_id}']"
                    ).text.strip().lower()
                    
                    if "yes" in checkbox_label:
                        if not checkbox.is_selected():
                            checkbox.click()
                        log_info(f"Selected 'Yes' for legal authorization question: {label}")
                        return
            
            # For "willing to relocate" questions, use the setting from config
            if "relocate" in label.lower() or "relocation" in label.lower():
                for checkbox in checkboxes:
                    label_id = checkbox.get_attribute("id")
                    checkbox_label = element.find_element(
                        By.XPATH, f".//label[@for='{label_id}']"
                    ).text.strip().lower()
                    
                    yes_selected = "yes" in checkbox_label and self.willing_to_relocate
                    no_selected = "no" in checkbox_label and not self.willing_to_relocate
                    
                    if yes_selected or no_selected:
                        if not checkbox.is_selected():
                            checkbox.click()
                        log_info(f"Selected {checkbox_label} for relocation question: {label}")
                        return
            
            # For other questions, if specific answer provided
            if answer and answer.lower() in ["yes", "no"]:
                for checkbox in checkboxes:
                    label_id = checkbox.get_attribute("id")
                    checkbox_label = element.find_element(
                        By.XPATH, f".//label[@for='{label_id}']"
                    ).text.strip().lower()
                    
                    if answer.lower() in checkbox_label:
                        if not checkbox.is_selected():
                            checkbox.click()
                        log_info(f"Selected {answer} for {label}")
                        return
            
            # If no specific action taken, check all boxes or first box
            # based on configuration
            if random_checkbox_answers:
                # Select random checkboxes (at least one)
                selected_count = 0
                for checkbox in checkboxes:
                    if random.choice([True, False]) or selected_count == 0:
                        if not checkbox.is_selected():
                            checkbox.click()
                        selected_count += 1
                
                log_info(f"Randomly selected {selected_count} options for {label}")
                self.randomly_answered_questions.add(f"{label} -> {selected_count} options")
            else:
                # Select the first checkbox
                if not checkboxes[0].is_selected():
                    checkboxes[0].click()
                
                # Get the selected option label
                label_id = checkboxes[0].get_attribute("id")
                selected_label = element.find_element(
                    By.XPATH, f".//label[@for='{label_id}']"
                ).text.strip()
                
                log_info(f"Selected first option {selected_label} for {label}")
                
        except Exception as e:
            log_error(f"Error answering checkbox question '{label}': {e}")
            
    def _get_answer_for_question(self, question):
        """
        Get the appropriate answer for a question based on predefined answers.
        
        Args:
            question: Question text
            
        Returns:
            str: Answer text or None if no match found
        """
        question_lower = question.lower()
        
        # Name fields
        if "first name" in question_lower:
            return first_name
        elif "last name" in question_lower:
            return last_name
        elif "full name" in question_lower:
            return f"{first_name} {last_name}"
            
        # Contact information
        elif "email" in question_lower:
            return self.email
        elif "phone" in question_lower:
            return self.phone
            
        # Address fields
        elif "city" in question_lower and "current" in question_lower:
            return self.current_city
        elif "city" in question_lower:
            return self.current_city
        elif "state" in question_lower:
            return self.current_state
        elif "zip" in question_lower or "postal" in question_lower:
            return self.current_zip
        elif "country" in question_lower:
            return self.current_country
            
        # Education
        elif "university" in question_lower or "college" in question_lower:
            return self.university
        elif "degree" in question_lower:
            return self.degree
        elif "field of study" in question_lower or "major" in question_lower:
            return self.field_of_study
            
        # Work experience
        elif "years of experience" in question_lower:
            return self.years_of_experience
        elif "current company" in question_lower:
            return self.current_company_name
        elif "job title" in question_lower:
            return self.current_title
            
        # Salary
        elif "salary" in question_lower:
            return self.desired_salary
            
        # Legal questions
        elif "legally authorized" in question_lower:
            return "Yes" if self.legally_authorized_to_work else "No"
        elif "sponsorship" in question_lower:
            return "No" if self.require_sponsorship else "Yes"
        elif "relocate" in question_lower:
            return "Yes" if self.willing_to_relocate else "No"
            
        # Check custom questions dictionary
        for key in custom_questions:
            if key.lower() in question_lower:
                return custom_questions[key]
                
        # No match found
        return None
        
    def _handle_resume_upload(self):
        """Handle resume upload if needed."""
        try:
            # Check for resume upload button
            upload_buttons = self.driver.find_elements(
                By.XPATH, 
                "//button[contains(@aria-label, 'Choose Resume') or contains(text(), 'Upload resume')]"
            )
            
            if upload_buttons:
                upload_button = upload_buttons[0]
                
                # Check if we need to use a new resume
                if self.default_resume_path and os.path.exists(self.default_resume_path):
                    upload_button.click()
                    time.sleep(1)
                    
                    # Send file path to file input
                    file_input = self.driver.find_element(By.XPATH, "//input[@type='file']")
                    file_input.send_keys(os.path.abspath(self.default_resume_path))
                    
                    log_info(f"Uploaded resume: {self.default_resume_path}")
                    
                    # Wait for upload to complete
                    time.sleep(2)
                    
        except Exception as e:
            log_error(f"Error handling resume upload: {e}")
            
    def _click_next_or_submit(self):
        """Click the Next or Submit button."""
        try:
            # Try to find the Next button
            next_buttons = self.driver.find_elements(
                By.XPATH, 
                "//button[contains(@aria-label, 'Continue to next step') or contains(text(), 'Next')]"
            )
            
            if next_buttons:
                next_buttons[0].click()
                log_info("Clicked Next button")
                return True
                
            # Try to find the Submit button
            submit_buttons = self.driver.find_elements(
                By.XPATH, 
                "//button[contains(@aria-label, 'Submit application') or contains(text(), 'Submit') or contains(text(), 'Review')]"
            )
            
            if submit_buttons:
                # Pause before submitting if configured
                if self.pause_before_submit:
                    log_info("Pausing before submission. Press Enter to continue...")
                    input()
                    
                submit_buttons[0].click()
                log_info("Clicked Submit button")
                return True
                
            # No button found
            return False
            
        except Exception as e:
            log_error(f"Error clicking Next/Submit button: {e}")
            return False
            
    def get_randomly_answered_questions(self):
        """
        Get the set of randomly answered questions.
        
        Returns:
            set: Set of randomly answered questions
        """
        return self.randomly_answered_questions

# Create a singleton instance
application_manager = ApplicationManager()

def get_application_manager(driver=None):
    """
    Get or create an application manager instance.
    
    Args:
        driver: Selenium WebDriver instance (default: None)
        
    Returns:
        ApplicationManager: Application manager instance
    """
    global application_manager
    
    if driver and application_manager.driver != driver:
        application_manager = ApplicationManager(driver)
        
    return application_manager 