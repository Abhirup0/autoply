'''
LinkedIn Auto Job Applier - Core Bot Implementation

This module contains the core functionality of the LinkedIn Auto Job Applier bot.
'''

import os
import csv
import re
import pyautogui
from random import choice, shuffle, randint
from datetime import datetime
from typing import Literal, Set, List, Dict, Optional, Tuple

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.select import Select
from selenium.webdriver.remote.webelement import WebElement
from selenium.common.exceptions import (
    NoSuchElementException, 
    ElementClickInterceptedException, 
    NoSuchWindowException, 
    ElementNotInteractableException
)

# Import configuration
from config.personals import *
from config.questions import *
from config.search import *
from config.secrets import use_AI, username, password
from config.settings import *

# Import modules
from modules.open_chrome import *
from modules.helpers import *
from modules.clickers_and_finders import *
from modules.validator import validate_config
from modules.ai.openai_client import create_openai_client

# Set up logging
from app.utils.logging import setup_logging, log_info, log_error, log_warning

logger = setup_logging(__name__)

pyautogui.FAILSAFE = False

class LinkedInBot:
    def __init__(self):
        self.tabs_count = 1
        self.easy_applied_count = 0
        self.external_jobs_count = 0
        self.failed_count = 0
        self.skip_count = 0
        self.daily_limit_reached = False
        self.randomly_answered_questions = set()
        self.use_new_resume = True
        self.linkedin_tab = None
        self.ai_client = None
        
        # User info
        self.first_name = first_name.strip()
        self.middle_name = middle_name.strip()
        self.last_name = last_name.strip()
        self.full_name = (self.first_name + " " + self.middle_name + " " + self.last_name 
                          if self.middle_name else self.first_name + " " + self.last_name)
        
        # Regex patterns
        self.re_experience = re.compile(r'[(]?\s*(\d+)\s*[)]?\s*[-to]*\s*\d*[+]*\s*year[s]?', re.IGNORECASE)
        
    def initialize(self):
        """Initialize the bot and validate configuration."""
        log_info("Initializing LinkedIn Auto Job Applier Bot")
        validate_config()
        
        if not os.path.exists(default_resume_path):
            pyautogui.alert(
                text=f'Your default resume "{default_resume_path}" is missing! Please update it\'s folder path "default_resume_path" in config.py\n\nOR\n\nAdd a resume with exact name and path (check for spelling mistakes including cases).\n\n\nFor now the bot will continue using your previous upload from LinkedIn!', 
                title="Missing Resume", 
                button="OK"
            )
            self.use_new_resume = False
            
        # Initialize AI if enabled
        if use_AI:
            try:
                self.ai_client = create_openai_client()
                log_info("AI client initialized successfully")
            except Exception as e:
                log_error(f"Failed to initialize AI client: {e}")
                
    def login_to_linkedin(self):
        """Login to LinkedIn."""
        log_info("Logging into LinkedIn")
        self.tabs_count = len(driver.window_handles)
        driver.get("https://www.linkedin.com/login")
        if not is_logged_in_LN(): 
            login_LN()
        self.linkedin_tab = driver.current_window_handle
        log_info("Successfully logged into LinkedIn")
        
    def run_cycle(self, cycle_number: int) -> int:
        """Run a single job application cycle."""
        if self.daily_limit_reached:
            return cycle_number
            
        log_info("\n########################################################################################################################\n")
        log_info(f"Date and Time: {datetime.now()}")
        log_info(f"Cycle number: {cycle_number}")
        log_info(f"Currently looking for jobs posted within '{date_posted}' and sorting them by '{sort_by}'")
        
        self.apply_to_jobs(search_terms)
        
        log_info("########################################################################################################################\n")
        
        if not self.daily_limit_reached:
            log_info("Sleeping for 10 min...")
            sleep(300)
            log_info("Few more min... Gonna start with in next 5 min...")
            sleep(300)
        buffer(3)
        
        return cycle_number + 1
    
    def apply_to_jobs(self, search_terms: list[str]) -> None:
        """Apply to jobs matching the search terms."""
        applied_jobs = self.get_applied_job_ids()
        
        for search_term in search_terms:
            try:
                log_info(f"\nSearching jobs for: {search_term}\n")
                self.search_jobs(search_term)
                # Rest of the implementation would go here
                # This would include handling job listings, applying to jobs, etc.
            except Exception as e:
                log_error(f"Error in apply_to_jobs: {e}")
    
    def get_applied_job_ids(self) -> set:
        """Get the IDs of jobs that have already been applied to."""
        applied_jobs = set()
        try:
            # Implementation would go here
            pass
        except Exception as e:
            log_error(f"Error getting applied job IDs: {e}")
        return applied_jobs
    
    def search_jobs(self, search_term: str) -> None:
        """Search for jobs with the given search term."""
        try:
            # Implementation would go here
            pass
        except Exception as e:
            log_error(f"Error searching for jobs: {e}")
    
    def answer_questions(self, modal: WebElement, questions_list: set, work_location: str) -> set:
        """Answer job application questions."""
        try:
            all_questions = modal.find_elements(By.XPATH, ".//div[@data-test-form-element]")
            # Rest of the implementation would go here
        except Exception as e:
            log_error(f"Error answering questions: {e}")
        return questions_list
    
    def run(self):
        """Run the LinkedIn Auto Job Applier bot."""
        try:
            log_info("Starting LinkedIn Auto Job Applier Bot")
            
            # Initialize and validate configuration
            self.initialize()
            
            # Login to LinkedIn
            self.login_to_linkedin()
            
            # Switch to LinkedIn tab
            driver.switch_to.window(self.linkedin_tab)
            
            # Start applying to jobs
            total_runs = 1
            total_runs = self.run_cycle(total_runs)
            
            # Display final statistics
            self.display_statistics(total_runs)
            
        except Exception as e:
            log_error(f"Error running bot: {e}")
        finally:
            # Clean up resources if needed
            pass
    
    def display_statistics(self, total_runs: int) -> None:
        """Display job application statistics."""
        log_info("\n\nTotal runs:                     {}".format(total_runs))
        log_info("Jobs Easy Applied:              {}".format(self.easy_applied_count))
        log_info("External job links collected:   {}".format(self.external_jobs_count))
        log_info("                              ----------")
        log_info("Total applied or collected:     {}".format(self.easy_applied_count + self.external_jobs_count))
        log_info("\nFailed jobs:                    {}".format(self.failed_count))
        log_info("Irrelevant jobs skipped:        {}\n".format(self.skip_count))
        
        if self.randomly_answered_questions: 
            log_info("\n\nQuestions randomly answered:\n  {}  \n\n".format(";\n".join(str(question) for question in self.randomly_answered_questions)))
        
        # Display a motivational quote
        quotes = [
            "You're one step closer than before.",
            "All the best with your future interviews.",
            "Keep up with the progress. You got this.",
            "If you're tired, learn to take rest but never give up.",
            "Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill",
            "Believe in yourself and all that you are. Know that there is something inside you that is greater than any obstacle. - Christian D. Larson",
            "Every job is a self-portrait of the person who does it. Autograph your work with excellence.",
            "The only way to do great work is to love what you do. If you haven't found it yet, keep looking. Don't settle. - Steve Jobs",
            "Opportunities don't happen, you create them. - Chris Grosser",
            "The road to success and the road to failure are almost exactly the same. The difference is perseverance.",
            "Obstacles are those frightful things you see when you take your eyes off your goal. - Henry Ford",
            "The only limit to our realization of tomorrow will be our doubts of today. - Franklin D. Roosevelt"
        ]
        log_info(f"\n{choice(quotes)}\n")


# Singleton instance
bot = LinkedInBot()

def run_bot():
    """Run the LinkedIn bot."""
    bot.run()


if __name__ == "__main__":
    run_bot() 