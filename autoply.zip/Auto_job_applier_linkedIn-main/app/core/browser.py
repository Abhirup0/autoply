'''
Browser Management Module

This module handles browser initialization and management for the LinkedIn Auto Job Applier.
'''

import os
import sys
import shutil
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

from app.utils.logging import setup_logging, log_info, log_error, log_warning

logger = setup_logging(__name__)

class BrowserManager:
    def __init__(self, headless=False, disable_images=True, user_data_dir=None):
        """
        Initialize the browser manager.
        
        Args:
            headless: Run browser in headless mode (default: False)
            disable_images: Disable image loading to speed up browsing (default: True)
            user_data_dir: Chrome user data directory for persistent sessions (default: None)
        """
        self.headless = headless
        self.disable_images = disable_images
        self.user_data_dir = user_data_dir
        self.driver = None
        
    def initialize_driver(self):
        """
        Initialize and return a Chrome WebDriver instance.
        
        Returns:
            WebDriver: Configured Chrome WebDriver instance
        """
        try:
            log_info("Initializing Chrome WebDriver")
            
            chrome_options = Options()
            
            # Configure headless mode
            if self.headless:
                chrome_options.add_argument('--headless')
                chrome_options.add_argument('--disable-gpu')
                chrome_options.add_argument('--window-size=1920,1080')
            
            # Configure user data directory if provided
            if self.user_data_dir:
                chrome_options.add_argument(f'--user-data-dir={self.user_data_dir}')
            
            # Common options for stability and performance
            chrome_options.add_argument('--disable-extensions')
            chrome_options.add_argument('--no-sandbox')
            chrome_options.add_argument('--disable-dev-shm-usage')
            chrome_options.add_argument('--disable-blink-features=AutomationControlled')
            chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            
            # Disable images if requested
            if self.disable_images:
                chrome_prefs = {"profile.default_content_setting_values": {"images": 2}}
                chrome_options.add_experimental_option("prefs", chrome_prefs)
            
            # Initialize Chrome WebDriver
            self.driver = webdriver.Chrome(
                service=Service(ChromeDriverManager().install()),
                options=chrome_options
            )
            
            # Configure browser window
            self.driver.maximize_window()
            
            log_info("Chrome WebDriver initialized successfully")
            return self.driver
            
        except Exception as e:
            log_error(f"Failed to initialize Chrome WebDriver: {e}")
            raise
            
    def close(self):
        """Close the browser."""
        if self.driver:
            try:
                log_info("Closing browser")
                self.driver.quit()
                self.driver = None
            except Exception as e:
                log_error(f"Error closing browser: {e}")
                
# Create a singleton instance
browser_manager = BrowserManager()

def get_driver(headless=False, disable_images=True, user_data_dir=None):
    """
    Get or create a WebDriver instance.
    
    Args:
        headless: Run browser in headless mode (default: False)
        disable_images: Disable image loading to speed up browsing (default: True)
        user_data_dir: Chrome user data directory for persistent sessions (default: None)
        
    Returns:
        WebDriver: Configured Chrome WebDriver instance
    """
    global browser_manager
    
    # Update configuration if needed
    if (browser_manager.headless != headless or 
        browser_manager.disable_images != disable_images or 
        browser_manager.user_data_dir != user_data_dir):
        
        # Close existing driver if it exists
        if browser_manager.driver:
            browser_manager.close()
            
        # Create new browser manager with updated configuration
        browser_manager = BrowserManager(headless, disable_images, user_data_dir)
    
    # Initialize driver if needed
    if not browser_manager.driver:
        return browser_manager.initialize_driver()
    
    return browser_manager.driver 