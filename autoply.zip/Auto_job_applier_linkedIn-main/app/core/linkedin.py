'''
LinkedIn Operations Module

This module handles LinkedIn-specific operations for the LinkedIn Auto Job Applier.
'''

import time
import re
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import (
    TimeoutException, 
    NoSuchElementException, 
    ElementClickInterceptedException
)

from config.secrets import username, password
from app.core.browser import get_driver
from app.utils.logging import setup_logging, log_info, log_error, log_warning

logger = setup_logging(__name__)

# Default timeout in seconds
DEFAULT_TIMEOUT = 10

class LinkedInOperations:
    def __init__(self, driver=None):
        """
        Initialize LinkedIn operations.
        
        Args:
            driver: Selenium WebDriver instance (default: None, will use global driver)
        """
        self.driver = driver if driver else get_driver()
        
    def is_logged_in(self):
        """
        Check if user is logged in to LinkedIn.
        
        Returns:
            bool: True if logged in, False otherwise
        """
        try:
            # Check for elements that only appear when logged in
            navbars = self.driver.find_elements(By.CLASS_NAME, "global-nav__nav")
            if navbars:
                log_info("Already logged in to LinkedIn")
                return True
                
            # Check if we're already on the login page
            if "login" in self.driver.current_url:
                log_info("On LinkedIn login page")
                return False
                
            # Navigate to login page and check again
            self.driver.get("https://www.linkedin.com/login")
            time.sleep(2)
            
            # Check for login form
            login_form = self.driver.find_elements(By.ID, "username")
            if login_form:
                log_info("Not logged in to LinkedIn")
                return False
                
            # If no login form found, we might be logged in
            log_info("Already logged in to LinkedIn")
            return True
            
        except Exception as e:
            log_error(f"Error checking login status: {e}")
            return False
            
    def login(self):
        """
        Login to LinkedIn using credentials from config.
        
        Returns:
            bool: True if login successful, False otherwise
        """
        try:
            if self.is_logged_in():
                return True
                
            log_info("Logging in to LinkedIn")
            
            # Navigate to login page
            self.driver.get("https://www.linkedin.com/login")
            time.sleep(2)
            
            # Enter username
            username_field = WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.presence_of_element_located((By.ID, "username"))
            )
            username_field.clear()
            username_field.send_keys(username)
            
            # Enter password
            password_field = WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.presence_of_element_located((By.ID, "password"))
            )
            password_field.clear()
            password_field.send_keys(password)
            
            # Click login button
            login_button = WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.element_to_be_clickable((By.XPATH, "//button[@type='submit']"))
            )
            login_button.click()
            
            # Wait for login to complete
            time.sleep(5)
            
            # Verify login
            return self.is_logged_in()
            
        except Exception as e:
            log_error(f"Login failed: {e}")
            return False
            
    def search_jobs(self, search_term, location=None, date_posted=None, sort_by=None):
        """
        Search for jobs on LinkedIn.
        
        Args:
            search_term: Job search query
            location: Location for job search (default: None)
            date_posted: Filter for job posting date (default: None)
            sort_by: Sort order for results (default: None)
            
        Returns:
            bool: True if search successful, False otherwise
        """
        try:
            log_info(f"Searching for jobs with term: {search_term}")
            
            # Navigate to jobs page
            self.driver.get("https://www.linkedin.com/jobs/")
            time.sleep(2)
            
            # Enter search term
            search_box = WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.presence_of_element_located((By.XPATH, "//input[contains(@aria-label, 'Search job titles')]"))
            )
            search_box.clear()
            search_box.send_keys(search_term)
            
            # Enter location if provided
            if location:
                location_box = WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                    EC.presence_of_element_located((By.XPATH, "//input[contains(@aria-label, 'City, state, or zip code')]"))
                )
                location_box.clear()
                location_box.send_keys(location)
            
            # Click search button
            search_button = WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(@aria-label, 'Search')]"))
            )
            search_button.click()
            
            # Wait for results to load
            time.sleep(5)
            
            # Apply filters if provided
            if date_posted:
                self._apply_date_filter(date_posted)
                
            if sort_by:
                self._apply_sort_filter(sort_by)
                
            # Wait for results to reload after filters
            time.sleep(3)
            
            # Check if we have results
            results = self.driver.find_elements(By.XPATH, "//div[contains(@class, 'jobs-search-results')]")
            if results:
                log_info("Job search completed successfully")
                return True
            else:
                log_warning("No job search results found")
                return False
                
        except Exception as e:
            log_error(f"Job search failed: {e}")
            return False
            
    def _apply_date_filter(self, date_posted):
        """Apply date filter to job search."""
        try:
            # Click on date posted filter
            date_filter = WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Date Posted')]"))
            )
            date_filter.click()
            
            # Select the appropriate option
            date_option = WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.element_to_be_clickable((By.XPATH, f"//label[contains(text(), '{date_posted}')]"))
            )
            date_option.click()
            
            # Apply filter
            apply_button = WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Apply')]"))
            )
            apply_button.click()
            
        except Exception as e:
            log_error(f"Error applying date filter: {e}")
            
    def _apply_sort_filter(self, sort_by):
        """Apply sort filter to job search."""
        try:
            # Click on sort dropdown
            sort_dropdown = WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(@aria-label, 'Sort by')]"))
            )
            sort_dropdown.click()
            
            # Select the appropriate option
            sort_option = WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.element_to_be_clickable((By.XPATH, f"//label[contains(text(), '{sort_by}')]"))
            )
            sort_option.click()
            
        except Exception as e:
            log_error(f"Error applying sort filter: {e}")
            
    def get_job_listings(self, max_listings=25):
        """
        Get job listings from search results.
        
        Args:
            max_listings: Maximum number of listings to retrieve (default: 25)
            
        Returns:
            list: List of job elements
        """
        try:
            # Wait for job listings to load
            WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.presence_of_element_located((By.XPATH, "//ul[contains(@class, 'jobs-search-results__list')]"))
            )
            
            # Get job listings
            job_listings = self.driver.find_elements(
                By.XPATH, "//li[contains(@class, 'jobs-search-results__list-item')]"
            )
            
            # Limit number of listings
            job_listings = job_listings[:min(len(job_listings), max_listings)]
            
            log_info(f"Found {len(job_listings)} job listings")
            return job_listings
            
        except Exception as e:
            log_error(f"Error getting job listings: {e}")
            return []
            
    def apply_easy_apply_filter(self):
        """
        Apply 'Easy Apply' filter to job search.
        
        Returns:
            bool: True if filter applied successfully, False otherwise
        """
        try:
            # Click on the easy apply filter
            easy_apply_button = WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Easy Apply')]"))
            )
            easy_apply_button.click()
            
            # Wait for results to reload
            time.sleep(3)
            
            log_info("Applied 'Easy Apply' filter")
            return True
            
        except Exception as e:
            log_error(f"Error applying 'Easy Apply' filter: {e}")
            return False
            
    def click_on_job(self, job_element):
        """
        Click on a job listing to view details.
        
        Args:
            job_element: WebElement of the job listing
            
        Returns:
            bool: True if clicked successfully, False otherwise
        """
        try:
            job_element.click()
            time.sleep(2)
            
            # Wait for job details to load
            WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.presence_of_element_located((By.XPATH, "//div[contains(@class, 'jobs-details')]"))
            )
            
            return True
            
        except Exception as e:
            log_error(f"Error clicking on job: {e}")
            return False
            
    def is_easy_apply_job(self):
        """
        Check if current job has Easy Apply button.
        
        Returns:
            bool: True if Easy Apply is available, False otherwise
        """
        try:
            easy_apply_buttons = self.driver.find_elements(
                By.XPATH, "//button[contains(@aria-label, 'Easy Apply')]"
            )
            return len(easy_apply_buttons) > 0
            
        except Exception as e:
            log_error(f"Error checking if job is Easy Apply: {e}")
            return False
            
    def click_easy_apply(self):
        """
        Click the Easy Apply button.
        
        Returns:
            bool: True if clicked successfully, False otherwise
        """
        try:
            easy_apply_button = WebDriverWait(self.driver, DEFAULT_TIMEOUT).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(@aria-label, 'Easy Apply')]"))
            )
            easy_apply_button.click()
            time.sleep(2)
            
            return True
            
        except Exception as e:
            log_error(f"Error clicking Easy Apply button: {e}")
            return False
            
# Create a singleton instance
linkedin = LinkedInOperations()

def get_linkedin_operations(driver=None):
    """
    Get or create a LinkedIn operations instance.
    
    Args:
        driver: Selenium WebDriver instance (default: None)
        
    Returns:
        LinkedInOperations: LinkedIn operations instance
    """
    global linkedin
    
    if driver and linkedin.driver != driver:
        linkedin = LinkedInOperations(driver)
        
    return linkedin 