import time
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import pyautogui

print("Starting job listing click test...")

try:
    # Initialize Chrome driver
    driver = uc.Chrome()
    print("Chrome driver initialized successfully")
    
    # Navigate to LinkedIn
    driver.get("https://www.linkedin.com/")
    print("Navigated to LinkedIn")
    
    # Wait for the page to load
    time.sleep(3)
    
    # Click on sign in button if on homepage
    try:
        sign_in_button = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(@class, 'nav__button-secondary') or contains(text(), 'Sign in')]"))
        )
        sign_in_button.click()
        print("Clicked on sign in button")
        time.sleep(2)
    except Exception as e:
        print(f"Could not find sign in button, might already be on login page: {e}")
    
    # Get LinkedIn credentials from config
    from config.secrets import username, password
    
    # Enter username
    try:
        username_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "username"))
        )
        username_field.clear()
        username_field.send_keys(username)
        print("Entered username")
    except Exception as e:
        print(f"Could not enter username: {e}")
        driver.save_screenshot("login_error_username.png")
        print("Screenshot saved as login_error_username.png")
        raise
    
    # Enter password
    try:
        password_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "password"))
        )
        password_field.clear()
        password_field.send_keys(password)
        print("Entered password")
    except Exception as e:
        print(f"Could not enter password: {e}")
        driver.save_screenshot("login_error_password.png")
        print("Screenshot saved as login_error_password.png")
        raise
    
    # Click login button
    try:
        login_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@type='submit']"))
        )
        login_button.click()
        print("Clicked login button")
    except Exception as e:
        print(f"Could not click login button: {e}")
        driver.save_screenshot("login_error_button.png")
        print("Screenshot saved as login_error_button.png")
        raise
    
    # Wait for login to complete
    time.sleep(10)
    
    # Navigate directly to a job search with Easy Apply filter
    driver.get("https://www.linkedin.com/jobs/search/?f_AL=true&keywords=Software%20Engineer")
    print("Navigated to Jobs page with Easy Apply filter")
    time.sleep(5)
    
    # Take a screenshot of search results
    driver.save_screenshot("search_results.png")
    print("Screenshot saved as search_results.png")
    
    # Try multiple different XPath selectors to find job listings
    selectors = [
        "//li[contains(@class, 'jobs-search-results__list-item')]",
        "//li[@data-occludable-job-id]",
        "//ul[contains(@class, 'jobs-search__results-list')]/li",
        "//div[contains(@class, 'job-card-container')]",
        "//div[contains(@class, 'job-card-list')]",
        "//a[contains(@class, 'job-card-list__title')]"
    ]
    
    job_listings = []
    successful_selector = ""
    
    for selector in selectors:
        try:
            print(f"Trying selector: {selector}")
            elements = driver.find_elements(By.XPATH, selector)
            if elements and len(elements) > 0:
                job_listings = elements
                successful_selector = selector
                print(f"Found {len(elements)} job listings with selector: {selector}")
                break
        except Exception as e:
            print(f"Selector {selector} failed: {e}")
    
    if not job_listings:
        print("Could not find any job listings with any selector")
        driver.save_screenshot("no_job_listings.png")
        print("Screenshot saved as no_job_listings.png")
        raise Exception("No job listings found")
    
    # Try different methods to click on the first job listing
    clicked = False
    
    # Method 1: Direct click
    try:
        print("Trying direct click on job listing")
        job_listings[0].click()
        clicked = True
        print("Successfully clicked job listing with direct click")
    except Exception as e:
        print(f"Direct click failed: {e}")
    
    if not clicked:
        # Method 2: Click on the title link
        try:
            print("Trying to click on title link")
            title_link = job_listings[0].find_element(By.TAG_NAME, "a")
            title_link.click()
            clicked = True
            print("Successfully clicked job listing title link")
        except Exception as e:
            print(f"Title link click failed: {e}")
    
    if not clicked:
        # Method 3: JavaScript click
        try:
            print("Trying JavaScript click")
            driver.execute_script("arguments[0].click();", job_listings[0])
            clicked = True
            print("Successfully clicked job listing with JavaScript")
        except Exception as e:
            print(f"JavaScript click failed: {e}")
    
    if not clicked:
        # Method 4: Actions click
        try:
            print("Trying Actions click")
            from selenium.webdriver.common.action_chains import ActionChains
            actions = ActionChains(driver)
            actions.move_to_element(job_listings[0]).click().perform()
            clicked = True
            print("Successfully clicked job listing with Actions")
        except Exception as e:
            print(f"Actions click failed: {e}")
    
    if not clicked:
        # Method 5: Scroll into view and click
        try:
            print("Trying scroll into view and click")
            driver.execute_script("arguments[0].scrollIntoView(true);", job_listings[0])
            time.sleep(1)
            job_listings[0].click()
            clicked = True
            print("Successfully clicked job listing after scrolling into view")
        except Exception as e:
            print(f"Scroll and click failed: {e}")
    
    # Wait to see if job details loaded
    time.sleep(5)
    
    # Take a screenshot to see if job details loaded
    driver.save_screenshot("after_click.png")
    print("Screenshot saved as after_click.png")
    
    # Check if job details loaded
    try:
        job_details = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//div[contains(@class, 'jobs-details')]"))
        )
        print("Job details loaded successfully!")
        
        # Look for Easy Apply button
        try:
            easy_apply_button = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//button[contains(@aria-label, 'Easy Apply') or contains(text(), 'Easy Apply')]"))
            )
            print("Found Easy Apply button!")
            driver.save_screenshot("easy_apply_button.png")
            print("Screenshot saved as easy_apply_button.png")
            
            # Print the successful selector for updating the main code
            print(f"\nSUCCESSFUL SELECTOR: {successful_selector}")
            print("You should update the job listing selector in runAiBot.py to use this selector")
            
        except Exception as e:
            print(f"Could not find Easy Apply button: {e}")
            driver.save_screenshot("no_easy_apply_button.png")
            print("Screenshot saved as no_easy_apply_button.png")
    except Exception as e:
        print(f"Job details did not load: {e}")
        driver.save_screenshot("no_job_details.png")
        print("Screenshot saved as no_job_details.png")
    
    # Keep the browser open for manual inspection
    print("Test completed. Browser will remain open for 30 seconds for inspection.")
    time.sleep(30)
    
    # Close the browser
    driver.quit()
    print("Browser closed")
    
except Exception as e:
    print(f"Test failed with error: {e}")
    try:
        driver.save_screenshot("job_listing_test_error.png")
        print("Error screenshot saved as job_listing_test_error.png")
        driver.quit()
    except:
        pass
