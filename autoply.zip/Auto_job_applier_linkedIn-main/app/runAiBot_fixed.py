'''
LinkedIn Auto Job Applier

License:    GNU Affero General Public License
            https://www.gnu.org/licenses/agpl-3.0.en.html
'''


# Imports
import os
import csv
import re
import pyautogui

from random import choice, shuffle, randint
from datetime import datetime

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.select import Select
from selenium.webdriver.remote.webelement import WebElement
from selenium.common.exceptions import NoSuchElementException, ElementClickInterceptedException, NoSuchWindowException, ElementNotInteractableException
from selenium.webdriver.common.action_chains import ActionChains

from config.personals import *
from config.questions import *
from config.search import *
from config.secrets import use_AI, username, password
from config.settings import *

from modules.open_chrome import *
from modules.helpers import *
from modules.clickers_and_finders import *
from modules.validator import validate_config
from modules.ai.openaiConnections import *

from typing import Literal


pyautogui.FAILSAFE = False
# if use_resume_generator:    from resume_generator import is_logged_in_GPT, login_GPT, open_resume_chat, create_custom_resume


#< Global Variables and logics

if run_in_background == True:
    pause_at_failed_question = False
    pause_before_submit = False
    run_non_stop = False

# Global variables
driver = None
wait = None
actions = None
linkedIn_tab = None
current_city = ""
failed_count = 0
skip_count = 0
easy_applied_count = 0
external_jobs_count = 0
tabs_count = 0
dailyEasyApplyLimitReached = False
useNewResume = False

# Enhanced functions for job listing interaction
def click_job_listing(driver, job):
    '''
    Enhanced function to click on a job listing using multiple methods
    Returns True if successful, False otherwise
    '''
    try:
        # Method 1: Direct click
        job.click()
        return True
    except:
        try:
            # Method 2: Click on the title link
            title_link = job.find_element(By.TAG_NAME, "a")
            title_link.click()
            return True
        except:
            try:
                # Method 3: JavaScript click
                driver.execute_script("arguments[0].click();", job)
                return True
            except:
                try:
                    # Method 4: Actions click
                    actions = ActionChains(driver)
                    actions.move_to_element(job).click().perform()
                    return True
                except:
                    try:
                        # Method 5: Scroll into view and click
                        driver.execute_script("arguments[0].scrollIntoView(true);", job)
                        time.sleep(1)
                        job.click()
                        return True
                    except:
                        return False

def find_job_listings(driver, wait):
    '''
    Enhanced function to find job listings using multiple selectors
    Returns a list of job listing elements
    '''
    # Wait until job listings are loaded
    selectors = [
        "//li[contains(@class, 'jobs-search-results__list-item')]",
        "//li[@data-occludable-job-id]",
        "//ul[contains(@class, 'jobs-search__results-list')]/li",
        "//div[contains(@class, 'job-card-container')]",
        "//div[contains(@class, 'job-card-list')]"
    ]
    
    for selector in selectors:
        try:
            wait.until(EC.presence_of_all_elements_located((By.XPATH, selector)))
            job_listings = driver.find_elements(By.XPATH, selector)
            if job_listings and len(job_listings) > 0:
                print_lg(f"Found job listings using selector: {selector}")
                return job_listings
        except:
            continue
    
    # If all selectors fail, try one more time with the original selector
    print_lg("All selectors failed, trying original selector as last resort")
    return driver.find_elements(By.XPATH, "//li[@data-occludable-job-id]")

# Function to apply to jobs
def apply_to_jobs(search_terms: list[str]) -> None:
    applied_jobs = get_applied_job_ids()
    rejected_jobs = set()
    blacklisted_companies = set()
    global current_city, failed_count, skip_count, easy_applied_count, external_jobs_count, tabs_count, pause_before_submit, pause_at_failed_question, useNewResume
    current_city = current_city.strip()

    if randomize_search_order:  shuffle(search_terms)
    for searchTerm in search_terms:
        driver.get(f"https://www.linkedin.com/jobs/search/?keywords={searchTerm}")
        print_lg("\n________________________________________________________________________________________________________________________\n")
        print_lg(f'\n>>>> Now searching for "{searchTerm}" <<<<\n\n')

        apply_filters()

        current_count = 0
        try:
            while current_count < switch_number:
                # Use enhanced function to find job listings
                job_listings = find_job_listings(driver, wait)
                
                if not job_listings or len(job_listings) == 0:
                    print_lg("No job listings found, trying to refresh the page")
                    driver.refresh()
                    buffer(5)
                    job_listings = find_job_listings(driver, wait)
                    if not job_listings or len(job_listings) == 0:
                        print_lg("Still no job listings found after refresh, moving to next search term")
                        break

                pagination_element, current_page = get_page_info()

                for job in job_listings:
                    if keep_screen_awake: pyautogui.press('shiftright')
                    if current_count >= switch_number: break
                    print_lg("\n-@-\n")

                    job_id,title,company,work_location,work_style,skip = get_job_main_details(job, blacklisted_companies, rejected_jobs)

                    if skip: continue
                    # Redundant fail safe check for applied jobs!
                    try:
                        if job_id in applied_jobs or find_by_class(driver, "jobs-s-apply__application-link", 2):
                            print_lg(f'Already applied to "{title} | {company}" job. Job ID: {job_id}!')
                            continue
                    except Exception as e:
                        print_lg(f'Trying to Apply to "{title} | {company}" job. Job ID: {job_id}')

                    # Use enhanced click function
                    if not click_job_listing(driver, job):
                        print_lg(f'Failed to click "{title} | {company}" job on details button. Job ID: {job_id}!')
                        discard_job()
                        continue

                    # Rest of the function remains the same...
                    # (The rest of the apply_to_jobs function would go here)

                # Rest of the while loop remains the same...
                # (The rest of the while loop would go here)

        except Exception as e:
            print_lg(f"Error in apply_to_jobs: {e}")

# The rest of the file would remain the same...
# (The rest of the original file would go here)

def main():
    global driver, wait, actions, linkedIn_tab
    
    # Validate configuration
    validate_config()
    
    # Initialize driver
    driver = get_driver()
    wait = WebDriverWait(driver, 10)
    actions = ActionChains(driver)
    
    # Login to LinkedIn
    driver.get("https://www.linkedin.com/login")
    buffer(2)
    
    try:
        # Enter username
        username_field = wait.until(EC.presence_of_element_located((By.ID, "username")))
        username_field.send_keys(username)
        
        # Enter password
        password_field = wait.until(EC.presence_of_element_located((By.ID, "password")))
        password_field.send_keys(password)
        
        # Click login button
        login_button = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[@type='submit']")))
        login_button.click()
        
        # Wait for login to complete
        buffer(5)
        
        # Store the LinkedIn tab
        linkedIn_tab = driver.current_window_handle
        
        # Run the job application process
        total_runs = 1
        while True:
            total_runs = run(total_runs)
            if not run_non_stop or dailyEasyApplyLimitReached:
                break
        
        print_lg("Job application process completed!")
        
    except Exception as e:
        print_lg(f"Error in main function: {e}")
    finally:
        # Close the browser
        try:
            driver.quit()
        except:
            pass

if __name__ == "__main__":
    main()
