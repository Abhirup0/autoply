'''
LinkedIn Auto Job Applier - Patch for Job Listing Click Issue

This patch updates the selectors and click methods for job listings to work with the current LinkedIn UI.
'''

import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains

def click_job_listing(driver, job):
    '''
    Enhanced function to click on a job listing using multiple methods
    Returns True if successful, False otherwise
    '''
    try:
        # Method 1: Direct click
        job.click()
        return True
    except:
        try:
            # Method 2: Click on the title link
            title_link = job.find_element(By.TAG_NAME, "a")
            title_link.click()
            return True
        except:
            try:
                # Method 3: JavaScript click
                driver.execute_script("arguments[0].click();", job)
                return True
            except:
                try:
                    # Method 4: Actions click
                    actions = ActionChains(driver)
                    actions.move_to_element(job).click().perform()
                    return True
                except:
                    try:
                        # Method 5: Scroll into view and click
                        driver.execute_script("arguments[0].scrollIntoView(true);", job)
                        time.sleep(1)
                        job.click()
                        return True
                    except:
                        return False

def find_job_listings(driver, wait):
    '''
    Enhanced function to find job listings using multiple selectors
    Returns a list of job listing elements
    '''
    # Wait until job listings are loaded
    selectors = [
        "//li[contains(@class, 'jobs-search-results__list-item')]",
        "//li[@data-occludable-job-id]",
        "//ul[contains(@class, 'jobs-search__results-list')]/li",
        "//div[contains(@class, 'job-card-container')]",
        "//div[contains(@class, 'job-card-list')]"
    ]
    
    for selector in selectors:
        try:
            wait.until(EC.presence_of_all_elements_located((By.XPATH, selector)))
            job_listings = driver.find_elements(By.XPATH, selector)
            if job_listings and len(job_listings) > 0:
                return job_listings
        except:
            continue
    
    # If all selectors fail, try one more time with the original selector
    return driver.find_elements(By.XPATH, "//li[@data-occludable-job-id]")

# To use these functions in runAiBot.py:
# 1. Add these functions to the file
# 2. Replace the job listing finding code with a call to find_job_listings()
# 3. Replace the job clicking code with a call to click_job_listing()

# Example usage:
'''
# Find all job listings in current page
buffer(3)
job_listings = find_job_listings(driver, wait)

for job in job_listings:
    if keep_screen_awake: pyautogui.press('shiftright')
    if current_count >= switch_number: break
    print_lg("\n-@-\n")

    job_id,title,company,work_location,work_style,skip = get_job_main_details(job, blacklisted_companies, rejected_jobs)

    if skip: continue
    # Redundant fail safe check for applied jobs!
    try:
        if job_id in applied_jobs or find_by_class(driver, "jobs-s-apply__application-link", 2):
            print_lg(f'Already applied to "{title} | {company}" job. Job ID: {job_id}!')
            continue
    except Exception as e:
        print_lg(f'Trying to Apply to "{title} | {company}" job. Job ID: {job_id}')
    
    # Use the enhanced click function
    if not click_job_listing(driver, job):
        print_lg(f'Failed to click "{title} | {company}" job. Job ID: {job_id}!')
        discard_job()
        continue
'''
