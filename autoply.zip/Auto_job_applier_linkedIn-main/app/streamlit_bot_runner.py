'''
LinkedIn Auto Job Applier - Streamlit Bot Runner

This script provides a bridge between the Streamlit UI and the bot.
It handles proper initialization and error reporting.
'''

import os
import sys
import traceback
import logging
from datetime import datetime

# Configure logging
log_dir = "logs"
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

log_file = os.path.join(log_dir, f"bot_run_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")

# Configure logging to both file and console
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler(sys.stdout)
    ]
)

# Create a global variable to store the log file path
global_log_file = log_file

def run_bot_with_logging():
    '''
    Run the bot with proper error handling and logging
    Returns a tuple of (success, log_file_path)
    '''
    try:
        logging.info("Starting bot run")
        print("Starting LinkedIn Auto Job Applier...")

        # Add the current directory to the path to ensure imports work
        current_dir = os.path.dirname(os.path.abspath(__file__))
        if current_dir not in sys.path:
            sys.path.insert(0, current_dir)

        # Import the bot
        try:
            import runAiBot
            logging.info("Successfully imported runAiBot")
        except ImportError as e:
            error_msg = f"Failed to import runAiBot: {str(e)}"
            logging.error(error_msg)
            print(error_msg)
            return False, global_log_file

        # Run the bot
        try:
            logging.info("Calling runAiBot.main()")
            runAiBot.main()
            logging.info("Bot run completed successfully")
            return True, global_log_file
        except Exception as e:
            error_msg = f"Error running bot: {str(e)}"
            logging.error(error_msg)
            logging.error(traceback.format_exc())
            print(error_msg)
            return False, global_log_file

    except Exception as e:
        error_msg = f"Unexpected error: {str(e)}"
        logging.error(error_msg)
        logging.error(traceback.format_exc())
        print(error_msg)
        return False, global_log_file

def get_log_file_path():
    '''
    Returns the path to the current log file
    '''
    return global_log_file

if __name__ == "__main__":
    success, log_file = run_bot_with_logging()
    if success:
        print(f"Bot run completed successfully. Log file: {log_file}")
    else:
        print(f"Bot run failed. Check log file for details: {log_file}")
