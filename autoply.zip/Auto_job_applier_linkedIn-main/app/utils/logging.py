'''
Logging Utility Module

This module provides standardized logging functionality for the LinkedIn Auto Job Applier.
'''

import os
import logging
import traceback
from datetime import datetime

# Create logs directory if it doesn't exist
if not os.path.exists('logs'):
    os.makedirs('logs')

# Global log file path
global_log_file = os.path.join('logs', f'linkedin_bot_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')

def setup_logging(name, level=logging.INFO):
    """
    Set up logging configuration for a module.
    
    Args:
        name: Name of the module (usually __name__)
        level: Logging level (default: INFO)
        
    Returns:
        Logger: Configured logger instance
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Check if handlers are already added to avoid duplicates
    if not logger.handlers:
        # Create file handler
        file_handler = logging.FileHandler(global_log_file)
        file_handler.setLevel(level)
        
        # Create console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(level)
        
        # Create formatter and add it to the handlers
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        # Add handlers to logger
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
    
    return logger

def log_info(message):
    """
    Log an info message to both console and file.
    
    Args:
        message: Message to log
    """
    logger = logging.getLogger('linkedin_bot')
    logger.info(message)
    print(message)

def log_error(message):
    """
    Log an error message to both console and file.
    
    Args:
        message: Error message to log
    """
    logger = logging.getLogger('linkedin_bot')
    logger.error(message)
    logger.error(traceback.format_exc())
    print(f"ERROR: {message}")

def log_warning(message):
    """
    Log a warning message to both console and file.
    
    Args:
        message: Warning message to log
    """
    logger = logging.getLogger('linkedin_bot')
    logger.warning(message)
    print(f"WARNING: {message}")

def log_debug(message):
    """
    Log a debug message to file only.
    
    Args:
        message: Debug message to log
    """
    logger = logging.getLogger('linkedin_bot')
    logger.debug(message)

def get_log_file_path():
    """
    Get the current log file path.
    
    Returns:
        str: Path to the current log file
    """
    return global_log_file 