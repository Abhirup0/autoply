'''
LinkedIn Auto Job Applier - Configuration Package

This package contains the configuration files for the LinkedIn Auto Job Applier.
''' 