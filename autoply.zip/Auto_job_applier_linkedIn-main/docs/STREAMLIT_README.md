# LinkedIn Auto Job Applier - Streamlit UI

A beautiful and user-friendly interface for the LinkedIn Auto Job Applier bot.

## Features

- **Intuitive UI**: Easy-to-use interface for configuring all aspects of the bot
- **Configuration Management**: Easily update and save your personal information, application questions, search preferences, and more
- **Visual Dashboard**: Monitor the status of your configurations and bot activity
- **Responsive Design**: Works on desktop and mobile devices
- **Secure**: Your credentials are stored locally and never shared

## Installation

1. Make sure you have Python 3.10 or above installed
2. Install the required packages:
   ```
   pip install -r streamlit_requirements.txt
   ```
3. Run the Streamlit app:
   ```
   streamlit run app.py
   ```

## Usage

1. Navigate through the sidebar to configure different aspects of the bot:
   - **Personal Information**: Your name, contact details, and other personal information
   - **Application Questions**: Your answers to common application questions
   - **Search Preferences**: Job search criteria and filters
   - **Authentication**: LinkedIn credentials and AI settings
   - **Settings**: General bot settings

2. After configuring all settings, go to the "Run Bot" page and click "Start Job Application Bot"

3. The bot will open a Chrome browser window and start applying for jobs based on your configurations

## Important Notes

- Make sure you have Google Chrome installed in the default location
- The bot uses Selenium for web automation, so it needs to control your browser
- You may need to manually log in to LinkedIn the first time
- Do not interact with the browser while the bot is running unless prompted

## Credits

LinkedIn Auto Job Applier - Streamlit UI

## License

GNU Affero General Public License - [https://www.gnu.org/licenses/agpl-3.0.en.html](https://www.gnu.org/licenses/agpl-3.0.en.html)
