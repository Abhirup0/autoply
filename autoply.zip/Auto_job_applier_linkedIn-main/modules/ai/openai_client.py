'''
LinkedIn Auto Job Applier - OpenAI Client

This module provides an interface to OpenAI's API for the LinkedIn Auto Job Applier.
'''

# Re-export the functions from openaiConnections to provide a consistent interface
from modules.ai.openaiConnections import ai_create_openai_client as create_openai_client
from modules.ai.openaiConnections import ai_close_openai_client as close_openai_client
from modules.ai.openaiConnections import ai_completion as completion
from modules.ai.openaiConnections import ai_extract_skills as extract_skills
from modules.ai.openaiConnections import ai_answer_question as answer_question
from modules.ai.openaiConnections import ai_check_job_relevance as check_job_relevance 