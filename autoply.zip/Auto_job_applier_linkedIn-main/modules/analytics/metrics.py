'''
Application Metrics Module

This module handles metrics collection and analysis for the LinkedIn Auto Job Applier.
'''

import os
import csv
import json
import datetime
from typing import Dict, List, Any, Optional, Tuple

import pandas as pd
import numpy as np

from app.utils.logging import setup_logging, log_info, log_error, log_warning

logger = setup_logging(__name__)

# Ensure data directory exists
data_dir = os.path.join('data', 'metrics')
if not os.path.exists(data_dir):
    os.makedirs(data_dir)

# File paths
METRICS_FILE = os.path.join(data_dir, 'application_metrics.csv')
JOB_DATA_FILE = os.path.join(data_dir, 'job_data.json')

class MetricsManager:
    def __init__(self):
        """Initialize the metrics manager."""
        self._ensure_files_exist()
        
    def _ensure_files_exist(self):
        """Ensure metric files exist with proper headers."""
        # Create metrics CSV if it doesn't exist
        if not os.path.exists(METRICS_FILE):
            log_info(f"Creating new metrics file: {METRICS_FILE}")
            with open(METRICS_FILE, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp',
                    'job_id',
                    'job_title',
                    'company',
                    'location',
                    'application_status',
                    'search_term',
                    'is_remote',
                    'application_method',
                    'time_taken',
                    'response_received',
                    'interview_offered'
                ])
        
        # Create job data JSON if it doesn't exist
        if not os.path.exists(JOB_DATA_FILE):
            log_info(f"Creating new job data file: {JOB_DATA_FILE}")
            with open(JOB_DATA_FILE, 'w') as f:
                json.dump({}, f)
        
    def record_application(self, 
                          job_id: str,
                          job_title: str,
                          company: str,
                          location: str,
                          status: str = 'applied',
                          search_term: str = '',
                          is_remote: bool = False,
                          application_method: str = 'easy_apply',
                          time_taken: float = 0.0,
                          job_details: Dict[str, Any] = None) -> bool:
        """
        Record a job application event.
        
        Args:
            job_id: LinkedIn job ID
            job_title: Job title
            company: Company name
            location: Job location
            status: Application status (default: 'applied')
            search_term: Search term used to find the job (default: '')
            is_remote: Whether the job is remote (default: False)
            application_method: Application method (default: 'easy_apply')
            time_taken: Time taken to apply in seconds (default: 0.0)
            job_details: Additional job details dict (default: None)
            
        Returns:
            bool: Success status
        """
        try:
            timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            # Record basic metrics in CSV
            with open(METRICS_FILE, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    timestamp,
                    job_id,
                    job_title,
                    company,
                    location,
                    status,
                    search_term,
                    '1' if is_remote else '0',
                    application_method,
                    f'{time_taken:.2f}',
                    '0',  # response_received, initially false
                    '0'   # interview_offered, initially false
                ])
            
            # Record detailed job data in JSON if provided
            if job_details:
                with open(JOB_DATA_FILE, 'r') as f:
                    job_data = json.load(f)
                
                job_data[job_id] = {
                    'timestamp': timestamp,
                    'job_title': job_title,
                    'company': company,
                    'location': location,
                    'status': status,
                    'search_term': search_term,
                    'is_remote': is_remote,
                    'application_method': application_method,
                    'time_taken': time_taken,
                    'response_received': False,
                    'interview_offered': False,
                    'details': job_details
                }
                
                with open(JOB_DATA_FILE, 'w') as f:
                    json.dump(job_data, f, indent=2)
            
            log_info(f"Recorded application for job {job_id} at {company}")
            return True
            
        except Exception as e:
            log_error(f"Error recording application metrics: {e}")
            return False
    
    def update_application_status(self, job_id: str, status: str, 
                                 response_received: bool = None, 
                                 interview_offered: bool = None) -> bool:
        """
        Update the status of a job application.
        
        Args:
            job_id: LinkedIn job ID
            status: New application status
            response_received: Whether a response was received (default: None)
            interview_offered: Whether an interview was offered (default: None)
            
        Returns:
            bool: Success status
        """
        try:
            # Update job data JSON
            with open(JOB_DATA_FILE, 'r') as f:
                job_data = json.load(f)
            
            if job_id in job_data:
                job_data[job_id]['status'] = status
                
                if response_received is not None:
                    job_data[job_id]['response_received'] = response_received
                    
                if interview_offered is not None:
                    job_data[job_id]['interview_offered'] = interview_offered
                
                with open(JOB_DATA_FILE, 'w') as f:
                    json.dump(job_data, f, indent=2)
                
                log_info(f"Updated status for job {job_id} to {status}")
                return True
            else:
                log_warning(f"Job ID {job_id} not found in job data")
                return False
            
        except Exception as e:
            log_error(f"Error updating application status: {e}")
            return False
    
    def get_application_statistics(self, start_date: str = None, 
                                  end_date: str = None) -> Dict[str, Any]:
        """
        Get application statistics for a date range.
        
        Args:
            start_date: Start date in 'YYYY-MM-DD' format (default: None, 30 days ago)
            end_date: End date in 'YYYY-MM-DD' format (default: None, today)
            
        Returns:
            dict: Dictionary of application statistics
        """
        try:
            # Set default date range if not provided
            if not end_date:
                end_date = datetime.datetime.now().strftime('%Y-%m-%d')
                
            if not start_date:
                start_date = (datetime.datetime.now() - datetime.timedelta(days=30)).strftime('%Y-%m-%d')
                
            # Load data from CSV
            if not os.path.exists(METRICS_FILE) or os.path.getsize(METRICS_FILE) == 0:
                return {
                    'total_applications': 0,
                    'daily_applications': {},
                    'application_methods': {},
                    'status_counts': {},
                    'response_rate': 0,
                    'interview_rate': 0,
                    'avg_time_taken': 0
                }
                
            df = pd.read_csv(METRICS_FILE)
            
            # Convert timestamp to datetime and filter by date range
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df = df[(df['timestamp'].dt.date >= pd.to_datetime(start_date).date()) & 
                    (df['timestamp'].dt.date <= pd.to_datetime(end_date).date())]
            
            if df.empty:
                return {
                    'total_applications': 0,
                    'daily_applications': {},
                    'application_methods': {},
                    'status_counts': {},
                    'response_rate': 0,
                    'interview_rate': 0,
                    'avg_time_taken': 0
                }
            
            # Calculate statistics
            total_applications = len(df)
            
            # Daily application counts
            daily_counts = df.groupby(df['timestamp'].dt.date).size()
            daily_applications = {str(date): count for date, count in daily_counts.items()}
            
            # Application methods
            application_methods = df['application_method'].value_counts().to_dict()
            
            # Status counts
            status_counts = df['application_status'].value_counts().to_dict()
            
            # Response and interview rates
            response_rate = df['response_received'].astype(int).mean() * 100 if 'response_received' in df else 0
            interview_rate = df['interview_offered'].astype(int).mean() * 100 if 'interview_offered' in df else 0
            
            # Average time taken
            avg_time_taken = df['time_taken'].astype(float).mean()
            
            # Remote vs non-remote
            remote_count = df['is_remote'].astype(int).sum()
            non_remote_count = total_applications - remote_count
            
            # Return statistics
            return {
                'total_applications': total_applications,
                'daily_applications': daily_applications,
                'application_methods': application_methods,
                'status_counts': status_counts,
                'response_rate': response_rate,
                'interview_rate': interview_rate,
                'avg_time_taken': avg_time_taken,
                'remote_count': remote_count,
                'non_remote_count': non_remote_count
            }
            
        except Exception as e:
            log_error(f"Error getting application statistics: {e}")
            return {
                'error': str(e)
            }
    
    def get_application_history(self) -> List[Dict[str, Any]]:
        """
        Get complete application history.
        
        Returns:
            list: List of application records
        """
        try:
            if not os.path.exists(METRICS_FILE) or os.path.getsize(METRICS_FILE) == 0:
                return []
                
            df = pd.read_csv(METRICS_FILE)
            
            # Convert to list of dictionaries
            applications = df.to_dict('records')
            
            # Add detailed information from job data if available
            if os.path.exists(JOB_DATA_FILE) and os.path.getsize(JOB_DATA_FILE) > 0:
                with open(JOB_DATA_FILE, 'r') as f:
                    job_data = json.load(f)
                
                for app in applications:
                    job_id = app['job_id']
                    if job_id in job_data and 'details' in job_data[job_id]:
                        app['details'] = job_data[job_id]['details']
            
            return applications
            
        except Exception as e:
            log_error(f"Error getting application history: {e}")
            return []

# Create a singleton instance
metrics_manager = MetricsManager()

def get_metrics_manager() -> MetricsManager:
    """
    Get the metrics manager instance.
    
    Returns:
        MetricsManager: Metrics manager instance
    """
    global metrics_manager
    return metrics_manager 