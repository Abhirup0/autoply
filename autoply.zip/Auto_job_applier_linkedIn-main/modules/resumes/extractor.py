'''
LinkedIn Auto Job Applier

License:    GNU Affero General Public License
            https://www.gnu.org/licenses/agpl-3.0.en.html
'''


from config.personals import *
from config.questions import default_resume_path



