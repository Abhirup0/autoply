#!/bin/bash

echo "Installing required packages..."
pip install -r streamlit_requirements.txt

echo "Creating logs directory..."
mkdir -p logs

echo "Testing logging functionality..."
python test_logging.py

echo "Starting Streamlit app..."
streamlit run app.py
