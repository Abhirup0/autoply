import os
import shutil

def create_directory(path):
    """Create a directory if it doesn't exist."""
    if not os.path.exists(path):
        os.makedirs(path)
        print(f"Created directory: {path}")
    else:
        print(f"Directory already exists: {path}")

def create_file(path, content=""):
    """Create a file with optional content if it doesn't exist."""
    if not os.path.exists(path):
        with open(path, 'w') as f:
            f.write(content)
        print(f"Created file: {path}")
    else:
        print(f"File already exists: {path}")

def setup_project_structure():
    """Set up the project directory structure."""
    # Main application directories
    create_directory("app")
    create_directory("app/core")
    create_directory("app/components")
    create_directory("app/utils")
    
    # Create __init__.py files in each directory
    create_file("app/__init__.py")
    create_file("app/core/__init__.py")
    create_file("app/components/__init__.py")
    create_file("app/utils/__init__.py")
    
    # Module directories
    create_directory("modules/analytics")
    create_directory("modules/market_analysis")
    create_directory("modules/network")
    create_directory("modules/platforms")
    create_directory("modules/resume")
    create_directory("modules/skills")
    
    # Create __init__.py files in each module directory
    create_file("modules/__init__.py")
    create_file("modules/analytics/__init__.py")
    create_file("modules/market_analysis/__init__.py")
    create_file("modules/network/__init__.py")
    create_file("modules/platforms/__init__.py")
    create_file("modules/resume/__init__.py")
    create_file("modules/skills/__init__.py")
    
    # Data directories
    create_directory("data")
    create_directory("data/jobs")
    create_directory("data/metrics")
    create_directory("data/templates")
    
    # Create __init__.py files in data directories
    create_file("data/__init__.py")
    create_file("data/jobs/__init__.py")
    create_file("data/metrics/__init__.py")
    create_file("data/templates/__init__.py")
    
    # Test directories
    create_directory("tests")
    create_directory("tests/unit")
    create_directory("tests/integration")
    
    # Create __init__.py files in test directories
    create_file("tests/__init__.py")
    create_file("tests/unit/__init__.py")
    create_file("tests/integration/__init__.py")
    
    # Scripts directory
    create_directory("scripts")
    
    # Ensure logs directory exists
    create_directory("logs")
    
    print("Project structure setup complete!")

if __name__ == "__main__":
    setup_project_structure() 