import time
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys

# Import credentials and search terms
try:
    from config.secrets import username, password
    from config.search import search_terms, search_location, easy_apply_only
    print(f"Using credentials from config: {username} (password hidden)")
    print(f"Search terms: {search_terms}")
    print(f"Search location: {search_location}")
    print(f"Easy Apply only: {easy_apply_only}")
except Exception as e:
    print(f"Error importing config: {e}")
    print("Using default test values")
    username = "test_username"
    password = "test_password"
    search_terms = ["Software Engineer"]
    search_location = "United States"
    easy_apply_only = True

print("Starting job application test...")

try:
    # Initialize Chrome driver
    driver = uc.Chrome()
    print("Chrome driver initialized successfully")
    
    # Navigate to LinkedIn
    driver.get("https://www.linkedin.com/")
    print("Navigated to LinkedIn")
    
    # Wait for the page to load
    time.sleep(3)
    
    # Click on sign in button if on homepage
    try:
        sign_in_button = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(@class, 'nav__button-secondary') or contains(text(), 'Sign in')]"))
        )
        sign_in_button.click()
        print("Clicked on sign in button")
        time.sleep(2)
    except Exception as e:
        print(f"Could not find sign in button, might already be on login page: {e}")
    
    # Enter username
    try:
        username_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "username"))
        )
        username_field.clear()
        username_field.send_keys(username)
        print("Entered username")
    except Exception as e:
        print(f"Could not enter username: {e}")
        driver.save_screenshot("login_error_username.png")
        print("Screenshot saved as login_error_username.png")
        raise
    
    # Enter password
    try:
        password_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "password"))
        )
        password_field.clear()
        password_field.send_keys(password)
        print("Entered password")
    except Exception as e:
        print(f"Could not enter password: {e}")
        driver.save_screenshot("login_error_password.png")
        print("Screenshot saved as login_error_password.png")
        raise
    
    # Click login button
    try:
        login_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@type='submit']"))
        )
        login_button.click()
        print("Clicked login button")
    except Exception as e:
        print(f"Could not click login button: {e}")
        driver.save_screenshot("login_error_button.png")
        print("Screenshot saved as login_error_button.png")
        raise
    
    # Wait for login to complete
    time.sleep(10)
    
    # Check if login was successful
    try:
        # Look for elements that would indicate successful login
        WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.XPATH, "//div[contains(@class, 'feed-identity-module') or contains(@class, 'global-nav')]"))
        )
        print("Login successful!")
        driver.save_screenshot("login_success.png")
        print("Screenshot saved as login_success.png")
    except Exception as e:
        print(f"Login verification failed: {e}")
        driver.save_screenshot("login_failed.png")
        print("Screenshot saved as login_failed.png")
        raise
    
    # Navigate to Jobs page
    try:
        driver.get("https://www.linkedin.com/jobs/")
        print("Navigated to Jobs page")
        time.sleep(5)
    except Exception as e:
        print(f"Could not navigate to Jobs page: {e}")
        driver.save_screenshot("jobs_navigation_error.png")
        print("Screenshot saved as jobs_navigation_error.png")
        raise
    
    # Enter search term
    try:
        search_term = search_terms[0].replace('"', '')
        search_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//input[contains(@aria-label, 'Search by title') or contains(@id, 'jobs-search-box-keyword')]"))
        )
        search_input.clear()
        search_input.send_keys(search_term)
        print(f"Entered search term: {search_term}")
    except Exception as e:
        print(f"Could not enter search term: {e}")
        driver.save_screenshot("search_term_error.png")
        print("Screenshot saved as search_term_error.png")
        raise
    
    # Enter location
    if search_location:
        try:
            location_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//input[contains(@aria-label, 'City, state, or zip code') or contains(@id, 'jobs-search-box-location')]"))
            )
            location_input.clear()
            location_input.send_keys(search_location)
            print(f"Entered location: {search_location}")
        except Exception as e:
            print(f"Could not enter location: {e}")
            driver.save_screenshot("location_error.png")
            print("Screenshot saved as location_error.png")
    
    # Click search button or press Enter
    try:
        # Try to find and click the search button
        try:
            search_button = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(@aria-label, 'Search') or contains(@class, 'jobs-search-box__submit')]"))
            )
            search_button.click()
            print("Clicked search button")
        except:
            # If button not found, press Enter in the search input
            print("Search button not found, pressing Enter instead")
            search_input.send_keys(Keys.ENTER)
            print("Pressed Enter to search")
        
        # Wait for search results
        time.sleep(10)
        
        # Take a screenshot of search results
        driver.save_screenshot("search_results.png")
        print("Screenshot saved as search_results.png")
        
        # Check if search results are displayed
        try:
            results = WebDriverWait(driver, 15).until(
                EC.presence_of_element_located((By.XPATH, "//ul[contains(@class, 'jobs-search__results-list')]"))
            )
            print("Search results found!")
            
            # If Easy Apply only is enabled, try to filter for Easy Apply jobs
            if easy_apply_only:
                try:
                    # Click on "All filters" button
                    all_filters_button = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'All filters') or contains(@aria-label, 'All filters')]"))
                    )
                    all_filters_button.click()
                    print("Clicked All filters button")
                    time.sleep(3)
                    
                    # Check the Easy Apply checkbox
                    easy_apply_checkbox = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.XPATH, "//label[contains(text(), 'Easy Apply')]//preceding-sibling::input or //span[contains(text(), 'Easy Apply')]//preceding-sibling::input"))
                    )
                    if not easy_apply_checkbox.is_selected():
                        driver.execute_script("arguments[0].click();", easy_apply_checkbox)
                        print("Selected Easy Apply filter")
                    else:
                        print("Easy Apply filter already selected")
                    
                    # Click Show results button
                    show_results_button = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Show results') or contains(@aria-label, 'Apply filters')]"))
                    )
                    show_results_button.click()
                    print("Clicked Show results button")
                    time.sleep(5)
                except Exception as e:
                    print(f"Could not filter for Easy Apply jobs: {e}")
                    driver.save_screenshot("easy_apply_filter_error.png")
                    print("Screenshot saved as easy_apply_filter_error.png")
            
            # Find job listings
            job_listings = driver.find_elements(By.XPATH, "//li[contains(@class, 'jobs-search-results__list-item')]")
            print(f"Found {len(job_listings)} job listings")
            
            if len(job_listings) > 0:
                # Click on the first job listing
                try:
                    job_listings[0].click()
                    print("Clicked on first job listing")
                    time.sleep(5)
                    
                    # Take a screenshot of the job details
                    driver.save_screenshot("job_details.png")
                    print("Screenshot saved as job_details.png")
                    
                    # Look for Easy Apply button
                    try:
                        easy_apply_button = WebDriverWait(driver, 10).until(
                            EC.presence_of_element_located((By.XPATH, "//button[contains(@aria-label, 'Easy Apply') or contains(text(), 'Easy Apply')]"))
                        )
                        print("Found Easy Apply button")
                        
                        # Don't actually click for this test
                        print("Test successful! Found job with Easy Apply button")
                        driver.save_screenshot("easy_apply_button_found.png")
                        print("Screenshot saved as easy_apply_button_found.png")
                    except Exception as e:
                        print(f"Could not find Easy Apply button: {e}")
                        driver.save_screenshot("no_easy_apply_button.png")
                        print("Screenshot saved as no_easy_apply_button.png")
                        
                        # Look for regular Apply button
                        try:
                            apply_button = WebDriverWait(driver, 5).until(
                                EC.presence_of_element_located((By.XPATH, "//button[contains(@aria-label, 'Apply') or contains(text(), 'Apply')]"))
                            )
                            print("Found regular Apply button")
                            print("Test partially successful! Found job with regular Apply button")
                            driver.save_screenshot("apply_button_found.png")
                            print("Screenshot saved as apply_button_found.png")
                        except Exception as e2:
                            print(f"Could not find any Apply button: {e2}")
                            driver.save_screenshot("no_apply_button.png")
                            print("Screenshot saved as no_apply_button.png")
                except Exception as e:
                    print(f"Could not click on job listing: {e}")
                    driver.save_screenshot("job_click_error.png")
                    print("Screenshot saved as job_click_error.png")
            else:
                print("No job listings found, search might have failed")
                driver.save_screenshot("no_job_listings.png")
                print("Screenshot saved as no_job_listings.png")
        except Exception as e:
            print(f"Could not find search results: {e}")
            driver.save_screenshot("no_search_results.png")
            print("Screenshot saved as no_search_results.png")
    
    except Exception as e:
        print(f"Search failed: {e}")
        driver.save_screenshot("search_error.png")
        print("Screenshot saved as search_error.png")
    
    # Keep the browser open for manual inspection
    print("Test completed. Browser will remain open for 30 seconds for inspection.")
    time.sleep(30)
    
    # Close the browser
    driver.quit()
    print("Browser closed")
    
except Exception as e:
    print(f"Test failed with error: {e}")
    try:
        driver.save_screenshot("job_apply_test_error.png")
        print("Error screenshot saved as job_apply_test_error.png")
        driver.quit()
    except:
        pass
