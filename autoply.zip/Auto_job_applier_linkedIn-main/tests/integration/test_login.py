import time
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Get LinkedIn credentials from config
from config.secrets import username, password

print(f"Using username: {username}")
print("Starting login test...")

try:
    # Initialize Chrome driver
    driver = uc.Chrome()
    print("Chrome driver initialized successfully")
    
    # Navigate to LinkedIn
    driver.get("https://www.linkedin.com/")
    print("Navigated to LinkedIn")
    
    # Wait for the page to load
    time.sleep(3)
    
    # Click on sign in button if on homepage
    try:
        sign_in_button = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(@class, 'nav__button-secondary') or contains(text(), 'Sign in')]"))
        )
        sign_in_button.click()
        print("Clicked on sign in button")
        time.sleep(2)
    except Exception as e:
        print(f"Could not find sign in button, might already be on login page: {e}")
    
    # Enter username
    try:
        username_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "username"))
        )
        username_field.clear()
        username_field.send_keys(username)
        print("Entered username")
    except Exception as e:
        print(f"Could not enter username: {e}")
        driver.save_screenshot("login_error_username.png")
        print("Screenshot saved as login_error_username.png")
        raise
    
    # Enter password
    try:
        password_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "password"))
        )
        password_field.clear()
        password_field.send_keys(password)
        print("Entered password")
    except Exception as e:
        print(f"Could not enter password: {e}")
        driver.save_screenshot("login_error_password.png")
        print("Screenshot saved as login_error_password.png")
        raise
    
    # Click login button
    try:
        login_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@type='submit']"))
        )
        login_button.click()
        print("Clicked login button")
    except Exception as e:
        print(f"Could not click login button: {e}")
        driver.save_screenshot("login_error_button.png")
        print("Screenshot saved as login_error_button.png")
        raise
    
    # Wait for login to complete
    time.sleep(10)
    
    # Check if login was successful
    try:
        # Look for elements that would indicate successful login
        WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.XPATH, "//div[contains(@class, 'feed-identity-module') or contains(@class, 'global-nav')]"))
        )
        print("Login successful!")
        driver.save_screenshot("login_success.png")
        print("Screenshot saved as login_success.png")
    except Exception as e:
        print(f"Login verification failed: {e}")
        driver.save_screenshot("login_failed.png")
        print("Screenshot saved as login_failed.png")
    
    # Keep the browser open for manual inspection
    print("Test completed. Browser will remain open for 30 seconds for inspection.")
    time.sleep(30)
    
    # Close the browser
    driver.quit()
    print("Browser closed")
    
except Exception as e:
    print(f"Test failed with error: {e}")
    try:
        driver.save_screenshot("login_test_error.png")
        print("Error screenshot saved as login_test_error.png")
        driver.quit()
    except:
        pass
