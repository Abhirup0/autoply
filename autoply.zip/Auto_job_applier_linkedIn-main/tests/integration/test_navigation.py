import time
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

print("Starting navigation test...")

try:
    # Initialize Chrome driver
    driver = uc.Chrome()
    print("Chrome driver initialized successfully")
    
    # Navigate to LinkedIn
    driver.get("https://www.linkedin.com/")
    print("Navigated to LinkedIn")
    
    # Wait for the page to load
    time.sleep(5)
    
    # Check if we can find the login button
    try:
        login_button = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(@class, 'nav__button-secondary') or contains(text(), 'Sign in')]"))
        )
        print("Login button found, navigation successful")
    except Exception as e:
        print(f"Could not find login button: {e}")
    
    # Take a screenshot
    driver.save_screenshot("linkedin_navigation_test.png")
    print("Screenshot saved as linkedin_navigation_test.png")
    
    # Close the browser
    driver.quit()
    print("Browser closed")
    
except Exception as e:
    print(f"Test failed with error: {e}")
