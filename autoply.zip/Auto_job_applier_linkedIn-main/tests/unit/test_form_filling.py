import time
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import TimeoutException, NoSuchElementException

# Import credentials and configuration
try:
    from config.secrets import username, password
    from config.personals import first_name, last_name, phone_number
    from config.questions import years_of_experience, require_visa, website, linkedIn
    print(f"Using credentials from config: {username} (password hidden)")
    print(f"Personal info: {first_name} {last_name}, {phone_number}")
    print(f"Experience: {years_of_experience} years")
except Exception as e:
    print(f"Error importing config: {e}")
    print("Using default test values")
    username = "test_username"
    password = "test_password"
    first_name = "Test"
    last_name = "User"
    phone_number = "1234567890"
    years_of_experience = "3"
    require_visa = "No"
    website = "https://example.com"
    linkedIn = "https://linkedin.com/in/testuser"

print("Starting form filling test...")

def fill_text_field(driver, field_id, value, timeout=10):
    """Attempt to fill a text field by various methods"""
    try:
        # Try by ID
        field = WebDriverWait(driver, timeout).until(
            EC.element_to_be_clickable((By.ID, field_id))
        )
        field.clear()
        field.send_keys(value)
        return True
    except:
        try:
            # Try by name
            field = WebDriverWait(driver, timeout).until(
                EC.element_to_be_clickable((By.NAME, field_id))
            )
            field.clear()
            field.send_keys(value)
            return True
        except:
            try:
                # Try by label text
                field = WebDriverWait(driver, timeout).until(
                    EC.element_to_be_clickable((By.XPATH, f"//label[contains(text(), '{field_id}')]//following::input[1]"))
                )
                field.clear()
                field.send_keys(value)
                return True
            except:
                try:
                    # Try by placeholder
                    field = WebDriverWait(driver, timeout).until(
                        EC.element_to_be_clickable((By.XPATH, f"//input[contains(@placeholder, '{field_id}')]"))
                    )
                    field.clear()
                    field.send_keys(value)
                    return True
                except:
                    return False

try:
    # Initialize Chrome driver
    driver = uc.Chrome()
    print("Chrome driver initialized successfully")
    
    # Navigate to LinkedIn
    driver.get("https://www.linkedin.com/")
    print("Navigated to LinkedIn")
    
    # Wait for the page to load
    time.sleep(3)
    
    # Click on sign in button if on homepage
    try:
        sign_in_button = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(@class, 'nav__button-secondary') or contains(text(), 'Sign in')]"))
        )
        sign_in_button.click()
        print("Clicked on sign in button")
        time.sleep(2)
    except Exception as e:
        print(f"Could not find sign in button, might already be on login page: {e}")
    
    # Enter username
    try:
        username_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "username"))
        )
        username_field.clear()
        username_field.send_keys(username)
        print("Entered username")
    except Exception as e:
        print(f"Could not enter username: {e}")
        driver.save_screenshot("login_error_username.png")
        print("Screenshot saved as login_error_username.png")
        raise
    
    # Enter password
    try:
        password_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "password"))
        )
        password_field.clear()
        password_field.send_keys(password)
        print("Entered password")
    except Exception as e:
        print(f"Could not enter password: {e}")
        driver.save_screenshot("login_error_password.png")
        print("Screenshot saved as login_error_password.png")
        raise
    
    # Click login button
    try:
        login_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@type='submit']"))
        )
        login_button.click()
        print("Clicked login button")
    except Exception as e:
        print(f"Could not click login button: {e}")
        driver.save_screenshot("login_error_button.png")
        print("Screenshot saved as login_error_button.png")
        raise
    
    # Wait for login to complete
    time.sleep(10)
    
    # Check if login was successful
    try:
        # Look for elements that would indicate successful login
        WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.XPATH, "//div[contains(@class, 'feed-identity-module') or contains(@class, 'global-nav')]"))
        )
        print("Login successful!")
        driver.save_screenshot("login_success.png")
        print("Screenshot saved as login_success.png")
    except Exception as e:
        print(f"Login verification failed: {e}")
        driver.save_screenshot("login_failed.png")
        print("Screenshot saved as login_failed.png")
        raise
    
    # Navigate to Jobs page with Easy Apply filter
    try:
        driver.get("https://www.linkedin.com/jobs/search/?f_AL=true&keywords=Software%20Engineer")
        print("Navigated to Jobs page with Easy Apply filter")
        time.sleep(5)
    except Exception as e:
        print(f"Could not navigate to Jobs page: {e}")
        driver.save_screenshot("jobs_navigation_error.png")
        print("Screenshot saved as jobs_navigation_error.png")
        raise
    
    # Find job listings
    try:
        job_listings = WebDriverWait(driver, 15).until(
            EC.presence_of_all_elements_located((By.XPATH, "//li[contains(@class, 'jobs-search-results__list-item')]"))
        )
        print(f"Found {len(job_listings)} job listings")
        
        if len(job_listings) > 0:
            # Click on the first job listing
            job_listings[0].click()
            print("Clicked on first job listing")
            time.sleep(5)
            
            # Take a screenshot of the job details
            driver.save_screenshot("job_details.png")
            print("Screenshot saved as job_details.png")
            
            # Look for Easy Apply button
            try:
                easy_apply_button = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.XPATH, "//button[contains(@aria-label, 'Easy Apply') or contains(text(), 'Easy Apply')]"))
                )
                print("Found Easy Apply button")
                
                # Click the Easy Apply button
                easy_apply_button.click()
                print("Clicked Easy Apply button")
                time.sleep(5)
                
                # Take a screenshot of the application form
                driver.save_screenshot("application_form.png")
                print("Screenshot saved as application_form.png")
                
                # Test form filling capabilities
                print("Testing form filling capabilities...")
                
                # Look for common form fields
                form_fields = {
                    "First Name": first_name,
                    "Last Name": last_name,
                    "Email": username,
                    "Phone": phone_number,
                    "Years of experience": years_of_experience,
                    "Website": website,
                    "LinkedIn": linkedIn
                }
                
                filled_fields = 0
                for field_name, field_value in form_fields.items():
                    if fill_text_field(driver, field_name, field_value, timeout=3):
                        print(f"Successfully filled {field_name} field")
                        filled_fields += 1
                    else:
                        print(f"Could not find or fill {field_name} field")
                
                print(f"Successfully filled {filled_fields} out of {len(form_fields)} fields")
                
                # Look for dropdown/select fields
                try:
                    select_elements = driver.find_elements(By.TAG_NAME, "select")
                    print(f"Found {len(select_elements)} dropdown fields")
                    
                    for i, select_element in enumerate(select_elements):
                        try:
                            select = Select(select_element)
                            options = select.options
                            if len(options) > 1:
                                select.select_by_index(1)  # Select the second option
                                print(f"Selected option in dropdown #{i+1}")
                        except Exception as e:
                            print(f"Could not interact with dropdown #{i+1}: {e}")
                except Exception as e:
                    print(f"Error finding dropdown fields: {e}")
                
                # Look for radio buttons
                try:
                    radio_buttons = driver.find_elements(By.XPATH, "//input[@type='radio']")
                    print(f"Found {len(radio_buttons)} radio buttons")
                    
                    for i, radio_button in enumerate(radio_buttons):
                        try:
                            if not radio_button.is_selected():
                                driver.execute_script("arguments[0].click();", radio_button)
                                print(f"Selected radio button #{i+1}")
                                break  # Only select one radio button per group
                        except Exception as e:
                            print(f"Could not interact with radio button #{i+1}: {e}")
                except Exception as e:
                    print(f"Error finding radio buttons: {e}")
                
                # Look for checkboxes
                try:
                    checkboxes = driver.find_elements(By.XPATH, "//input[@type='checkbox']")
                    print(f"Found {len(checkboxes)} checkboxes")
                    
                    for i, checkbox in enumerate(checkboxes):
                        try:
                            if not checkbox.is_selected():
                                driver.execute_script("arguments[0].click();", checkbox)
                                print(f"Toggled checkbox #{i+1}")
                        except Exception as e:
                            print(f"Could not interact with checkbox #{i+1}: {e}")
                except Exception as e:
                    print(f"Error finding checkboxes: {e}")
                
                # Take a screenshot after filling the form
                driver.save_screenshot("form_filled.png")
                print("Screenshot saved as form_filled.png")
                
                # Look for Next or Submit button
                try:
                    next_button = WebDriverWait(driver, 5).until(
                        EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Next') or contains(text(), 'Submit') or contains(text(), 'Review')]"))
                    )
                    print(f"Found button: {next_button.text}")
                    
                    # Don't actually click for this test
                    print("Test successful! Found form with Next/Submit button")
                except Exception as e:
                    print(f"Could not find Next/Submit button: {e}")
                    driver.save_screenshot("no_next_button.png")
                    print("Screenshot saved as no_next_button.png")
            except Exception as e:
                print(f"Could not find or click Easy Apply button: {e}")
                driver.save_screenshot("easy_apply_error.png")
                print("Screenshot saved as easy_apply_error.png")
        else:
            print("No job listings found")
            driver.save_screenshot("no_job_listings.png")
            print("Screenshot saved as no_job_listings.png")
    except Exception as e:
        print(f"Could not find job listings: {e}")
        driver.save_screenshot("job_listings_error.png")
        print("Screenshot saved as job_listings_error.png")
    
    # Keep the browser open for manual inspection
    print("Test completed. Browser will remain open for 30 seconds for inspection.")
    time.sleep(30)
    
    # Close the browser
    driver.quit()
    print("Browser closed")
    
except Exception as e:
    print(f"Test failed with error: {e}")
    try:
        driver.save_screenshot("form_filling_test_error.png")
        print("Error screenshot saved as form_filling_test_error.png")
        driver.quit()
    except:
        pass
