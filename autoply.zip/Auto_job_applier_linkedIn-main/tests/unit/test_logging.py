'''
Test script to verify that logging works correctly
'''

import os
import sys
import logging
from datetime import datetime

# Configure logging
log_dir = "logs"
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

log_file = os.path.join(log_dir, f"test_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")

# Configure logging to both file and console
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler(sys.stdout)
    ]
)

# Log some test messages
logging.info("This is a test info message")
logging.warning("This is a test warning message")
logging.error("This is a test error message")

# Print the log file path
print(f"Log file created at: {log_file}")

# Read and print the log file content
try:
    with open(log_file, 'r') as f:
        content = f.read()
        print("\nLog file content:")
        print(content)
except Exception as e:
    print(f"Error reading log file: {str(e)}")

print("\nLogging test completed successfully!")
